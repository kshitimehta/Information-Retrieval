package inference;

public class FilterReject extends FilterOperator {

	public FilterReject(ProximityNode pn, QueryNode q) {
		super(pn,q);
	}
	
	@Override
	public int nextCandidate() {
		return query.nextCandidate();
	}
	
	@Override
	public double score(int docId) {
		if(filter.p.getCurrentPosting().getDocId() !=docId) {
			return query.score(docId);
		}
		else
			return -1.0;
	}
	
}
