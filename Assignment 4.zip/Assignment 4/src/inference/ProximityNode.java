package inference;

import index.Index;
import index.Posting;
import index.PostingList;

import retrieval.RetrievalModel;

public abstract class ProximityNode implements QueryNode {
	Index index;
	PostingList p;
	int ctf;
	RetrievalModel model;
	
	public boolean hasMore() {
		if (p.getCurrentPosting()==null)
			return false;
		return true;
	}
		
	public void skipTo(int docId) {
		p.skipTo(docId);
	}
		
	public int nextCandidate() {
		int docval = -1;
		try {
		return p.getCurrentPosting().getDocId();
		}
		catch(NullPointerException e) {};
		return docval;
	}
	
	public double score(int docId) {
	Posting pl = p.getCurrentPosting();
	int tf = 0;
	if(pl!=null)
		if (p.getCurrentPosting().getDocId()==docId)
			tf = pl.getTermFreq();
	
	int docLen = index.getDocLength(docId);

	return model.scoreOccurrence(tf, ctf, docLen);		
	}

	
}
