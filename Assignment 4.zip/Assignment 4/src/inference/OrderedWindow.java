package inference;

import index.Index;
import index.PostingList;
import retrieval.RetrievalModel;
import java.util.ArrayList;

public class OrderedWindow extends ProximityNode {

	String term;
	int ctf = 0;
	public OrderedWindow(){};
	public OrderedWindow(int winsize,ArrayList<ProximityNode> children,Index i,RetrievalModel m){

		p = this.createPostingList(winsize,children); 
		while(p.hasMore())
		{	int currDocId = p.getCurrentPosting().getDocId();
			ctf += p.getCurrentPosting().getPositionsArray().length; 
			p.skipTo(currDocId+1);
		}
		p.startIteration(); 
	}
	
	
	public PostingList createPostingList(int winsize,ArrayList<ProximityNode> children) {
		PostingList pl = new PostingList();
					
		while(children.get(0).p.hasMore()) {
			int current_doc = -1;
			for(int i =0; i<children.size();i++){ 
				
				if(children.get(i).p.getCurrentPosting()!=null) { 
					if(children.get(i).p.getCurrentPosting().getDocId() > current_doc) {
						current_doc = children.get(i).p.getCurrentPosting().getDocId();
					}
				}	
				else { 
					current_doc = -1;
					break;
				}
			}
			if(current_doc == -1) 
				break;
			int current_position = -1;
			
			for(int i=0;i<children.size();i++){
				children.get(i).p.skipTo(current_doc); 
				if(children.get(i).p.getCurrentPosting()!=null){ 
					
					if (children.get(i).p.getCurrentPosting().getDocId() != current_doc){	
						
						break;  
					}
					else{
						
						current_position = children.get(0).p.getCurrentPosting().getCurrentPosition(); 
						if(i==children.size()-1){ 
							int minD=-1;
							int minPosition=1000000;
							for(int j=0;j<children.size();j++) {
								if(children.get(j).p.getCurrentPosting()!=null) {
									int size= children.get(j).p.getCurrentPosting().getPositionsArray().length;
									if(size < minPosition) {
											minPosition=size;
											minD = j;
									}
								}
								else {
									minD= -1;
									break;
								}
							}
							if(minD==-1) {
								break;
							}
							ArrayList<Integer> positions = new ArrayList<Integer>();								
							boolean loop_break=false;
							
							while(children.get(minD).p.getCurrentPosting().hasMore() && loop_break==false){ 
								
								positions.clear();
								current_position = children.get(0).p.getCurrentPosting().getCurrentPosition();
								for(int j=0;j<children.size();j++){
									children.get(j).p.getCurrentPosting().skipTo(current_position+j); 
									int pos = children.get(j).p.getCurrentPosting().getCurrentPosition();
									if(positions.contains(pos)) {
										pos = children.get(j).p.getCurrentPosting().getCurrentPosition();
										children.get(j).p.getCurrentPosting().skipTo(pos+1);	
										pos = children.get(j).p.getCurrentPosting().getCurrentPosition();
										positions.add(pos);
										
									}
									if(pos==-1){	
										loop_break=true;
										break;								
									}
									else {
										
										if((children.get(j).p.getCurrentPosting().getCurrentPosition() > current_position+j*winsize) && (children.get(j).p.getCurrentPosting().getCurrentPosition()< current_position+(j-1)*winsize)){
											children.get(0).p.getCurrentPosting().skipTo(current_position+1); 
											current_position = children.get(0).p.getCurrentPosting().getCurrentPosition();
											break; 
										}
										else{
											
											if(j == children.size()-1){
												pl.add(current_doc,current_position);
												
												children.get(0).p.getCurrentPosting().skipTo(current_position+1); 
												current_position = children.get(0).p.getCurrentPosting().getCurrentPosition();											
											}
										}
									}	
								}	
									
							}
							
							for(int k=0;k<children.size();k++){
								children.get(k).p.skipTo(current_doc+1);
							}
							current_doc = -1;
						}	
					}
			}
		}		
		
		}
	return pl;	
	}
	
}	
	

