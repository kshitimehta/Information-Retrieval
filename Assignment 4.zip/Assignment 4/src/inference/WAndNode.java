package inference;

import java.util.ArrayList;


public class WAndNode extends BeliefNode{
	
	ArrayList<Double> weights;
	
	public WAndNode(ArrayList<? extends QueryNode> children, ArrayList<Double> wts){
		
		super(children);
		weights=wts;
	}

	public double score(int docId) {
		double score =0.0;
		for(int i=0;i<children.size();i++)
		{
			score += weights.get(i)*children.get(i).score(docId);		
		}
		
		return score;	
	}
	
}
