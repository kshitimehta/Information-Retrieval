package inference;

import java.util.AbstractMap;
import java.util.PriorityQueue;
import java.util.Map;
import java.util.List;
import java.util.ArrayList;
import java.util.Comparator;

public class InferenceNetwork {

	public List<Map.Entry<Integer,Double>> runQuery(QueryNode qnode,int k){
		PriorityQueue<Map.Entry<Integer,Double>> result = new PriorityQueue<>(Map.Entry.<Integer,Double>comparingByValue());
		while(qnode.hasMore()) {
			int d = qnode.nextCandidate();
			qnode.skipTo(d);
			Double curScore = qnode.score(d);
			if(curScore !=null) {
				result.add(new AbstractMap.SimpleEntry<Integer,Double>(d,curScore));
				if(result.size() >k) {
					result.poll();
				}
			}
			qnode.skipTo(d+1);
		}

		ArrayList<Map.Entry<Integer,Double>> scores = new ArrayList<Map.Entry<Integer,Double>>();
		scores.addAll(result);
		scores.sort(Map.Entry.<Integer,Double>comparingByValue(Comparator.reverseOrder()));
		return scores;
		
	}
	
}
