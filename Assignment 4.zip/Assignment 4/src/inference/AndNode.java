package inference;

//import inference.ProximityNode;
import java.util.ArrayList;

public class AndNode extends BeliefNode{
	public AndNode(ArrayList<? extends QueryNode> c){
		super(c);
	}
	
	public double score(int docId) {
	
		return children.stream().mapToDouble(c -> c.score(docId)).sum();	
	}
	
}