package inference;

import java.util.ArrayList;

public class NotNode extends BeliefNode{

	public NotNode(ArrayList<? extends QueryNode> children){
		super(children);
	}
	
	public double score(int docId) {
		
		return Math.log(1-Math.exp(children.get(0).score(docId)));	
	}
	
}

