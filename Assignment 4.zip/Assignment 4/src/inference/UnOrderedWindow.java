package inference;

import java.util.ArrayList;

import index.Index;
import index.Posting;
import index.PostingList;
import retrieval.RetrievalModel;


public class UnOrderedWindow extends ProximityNode {

	public UnOrderedWindow(){};
	public UnOrderedWindow(int window,ArrayList<ProximityNode> children,Index i,RetrievalModel m){
		p = this.createPostingList(window,children);
		while(p.hasMore())
		{
			int docid = p.getCurrentPosting().getDocId();
			ctf += p.getCurrentPosting().getPositionsArray().length;
			p.skipTo(docid+1);
		}
		p.startIteration();
		
	}
	
	
	public PostingList createPostingList(int window,ArrayList<ProximityNode> children) {
		PostingList pl = new PostingList();
		int maxDoc = -1;
		int minSize = 1000;
		
		for(int a=0;a<children.size();a++) {
			if (children.get(a).p.documentCount()<minSize) {
				minSize = children.get(a).p.documentCount();
				maxDoc = a;
			}		
		}
		
		while(children.get(maxDoc).p.getCurrentPosting()!=null) {
			
			
			int minposition = children.get(maxDoc).p.getCurrentPosting().getDocId();
			int current_doc = -1;
		
			for(int q=0;q<children.size();q++){
				if(children.get(q).p.getCurrentPosting()!=null) { 
					if(children.get(q).p.getCurrentPosting().getDocId() > current_doc) {
						current_doc = children.get(q).p.getCurrentPosting().getDocId();
					}
				}
				else {
					
					current_doc = -1;
					break;
				}
			}
			if(current_doc == -1)
				break;
				
			int current_position = 1000000;
			for(int i=0;i<children.size();i++){
				children.get(i).p.skipTo(current_doc); 

				if(children.get(i).p.getCurrentPosting()!=null) {
					
				
					if (children.get(i).p.getCurrentPosting().getDocId() != current_doc){
						
							
						break;  
					}	
					else{
	
						if (i==0){
							current_position = 10000000; 
						}	
						if(i==children.size()-1){
							
							Posting posl = children.get(0).p.getCurrentPosting();
							int max_position = -1;
							ArrayList<Integer> positions = new ArrayList<Integer>();						
							int max_window_position = -1;
							boolean loop_break = false;
							int pointer = -2;	
							positions.clear();
							while(loop_break==false){

								positions.clear();
								max_window_position = -1;
								for(int m=0;m<children.size();m++){ 
									 
									int posTerm = children.get(m).p.getCurrentPosting().getCurrentPosition();	
									if(posTerm!=-1) {
										
										if(positions.contains(posTerm)) {
											children.get(m).p.getCurrentPosting().skipTo(posTerm+1);
											posTerm = children.get(m).p.getCurrentPosting().getCurrentPosition();
											positions.add(posTerm);									
										}
										else {
											positions.add(posTerm);									
										}
										
										if(posTerm < current_position) {	
											current_position = children.get(m).p.getCurrentPosting().getCurrentPosition();
											pointer = m;
										}
										
										if(max_window_position<posTerm) {
											max_window_position = posTerm;
										}
									}
									else {
										
										max_window_position = -1;
										loop_break = true;
										break;
									}
								}
								if(max_window_position == -1) {
									
									break;
								}
								if(posl.getCurrentPosition()!=-1 && loop_break ==false) {
									
									
									max_position = current_position+window;
									
									if(max_window_position<max_position) {
										pl.add(current_doc,current_position);
										
										for(int m=0;m<children.size();m++) {
											
											int pos = children.get(m).p.getCurrentPosting().getCurrentPosition();
											children.get(m).p.getCurrentPosting().skipTo(pos+1);
											if(children.get(m).p.getCurrentPosting().getCurrentPosition()== -1) {
												loop_break = true;
												break;
											}
												
										}
									}
									else {
										
										children.get(pointer).p.getCurrentPosting().skipTo(current_position+1);
										current_position = 10000000;
										
										if(children.get(pointer).p.getCurrentPosting().getCurrentPosition()== -1) {
											
											loop_break = true;
											break;
										}								
									}
								}
														
							}
						
						}
					}
			}	
			else {
				
					break;
			}

			}
			
			children.get(maxDoc).p.skipTo(minposition+1);	
		}
		
		
	return pl;
	}
}
