package inference;

import java.util.ArrayList;

import java.lang.Math; 

public class SumNode extends BeliefNode implements QueryNode {
	
	
	public SumNode(ArrayList<? extends QueryNode> c){
		super(c);
	}
	@Override
	public double score(int docId) {
		double score =0.0;

		for(QueryNode child:children)
		{	
			score += Math.exp(child.score(docId));		
		}
		
		return Math.log(score)/children.size();	
	}
		
	
}
