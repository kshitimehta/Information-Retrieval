package inference;

import java.util.ArrayList;

import java.lang.Math; 

public class WSumNode extends BeliefNode {
	
	ArrayList<Double> weights;
	public WSumNode(ArrayList<? extends QueryNode> children, ArrayList<Double> wts){
		super(children);
		weights = wts;
	}

	public double score(int docId) {
		double score =0.0;
		for(int i=0;i<children.size();i++)
		{
			score += Math.exp((children.get(i).score(docId))*weights.get(i));		
		}
		
		return Math.log(score/children.size());	
	}

	
}
