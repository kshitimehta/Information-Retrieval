package inference;

import index.Index;
import retrieval.RetrievalModel;

public class TermNode extends ProximityNode {
	
	public TermNode(String term,Index i,RetrievalModel m){
		index = i;
		model = m;
		p = this.index.getPostings(term);
		ctf = index.getTermFreq(term);
	}
	
}
