package inference;

import java.util.ArrayList;

public abstract class BeliefNode implements QueryNode{

	ArrayList<? extends QueryNode> children;
	
	BeliefNode(ArrayList<? extends QueryNode> c){
		children = c;
	}	
	
	public boolean hasMore() {
		for(QueryNode child: children) {
			if(child.hasMore()==true) {
				return true;
			}
		}
		return false;
	}
	
	
	public int nextCandidate() {
		int minChild = 100000000;
		for(QueryNode child: children) {
			if(child.nextCandidate()!= -1) {
				if(minChild>child.nextCandidate())
					minChild = child.nextCandidate();
			}
		}
		return minChild;
		
	}
	
	
	public void skipTo(int docId) {
		for(QueryNode child: children) {
			child.skipTo(docId);
		}
	}	
}
