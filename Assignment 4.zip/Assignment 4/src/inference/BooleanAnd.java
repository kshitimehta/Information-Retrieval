package inference;

import java.util.ArrayList;

import index.Index;
import index.PostingList;
import retrieval.RetrievalModel;


public class BooleanAnd extends ProximityNode {

	public BooleanAnd(ArrayList<ProximityNode> children,Index i,RetrievalModel m){
		p = this.createPostingList(children);
		while(p.hasMore())
		{
			int d = p.getCurrentPosting().getDocId();
			ctf += p.getCurrentPosting().getPositionsArray().length;
			p.skipTo(d+1);
		}
		p.startIteration();
		
	}
	public PostingList createPostingList(ArrayList<ProximityNode> children) {
		PostingList cp = new PostingList();
		int b = -1;
		int minSize = 1000;
		// find smallest posting list.
		for(int a=0;a<children.size();a++) {
			if (children.get(a).p.documentCount()<minSize) {
				minSize = children.get(a).p.documentCount();
				b = a;
			}		
		}
		
		while(children.get(b).p.getCurrentPosting()!=null) {
			
			// find the first common document.
			int current_doc = -1;
			int a = 0;
			for(int q=0;q<children.size();q++){
				if(children.get(q).p.getCurrentPosting()!=null) { /// check for complete traversal of one of the lists.
					if(children.get(q).p.getCurrentPosting().getDocId() > current_doc) {
						current_doc = children.get(q).p.getCurrentPosting().getDocId();
						a = q;
					}
				}
				else {
					// break loop to find window in a new common doc because there are no more common docs.
					current_doc = -1;
					break;
				}
			}
			if(current_doc == -1)
				// breaking outer while loop because there are no common docs.
				break;				
			for(int i=0;i<children.size();i++){
				children.get(i).p.skipTo(current_doc); // shift to common document

				if(children.get(i).p.getCurrentPosting()!=null) {
					
				
					if (children.get(i).p.getCurrentPosting().getDocId() != current_doc){
						children.get(a).p.skipTo(current_doc+1);
						break;  //break loop because the potentially common document isn't common.
					}	
					else{

						if(i==children.size()-1){
							int pos = children.get(0).p.getCurrentPosting().getCurrentPosition();
							cp.add(current_doc, pos);
							for(int j=0;j<children.size();j++)
								children.get(j).p.skipTo(current_doc+1);
						}	
					}
				}
				else {
					break;
				}
			}
			children.get(b).p.skipTo(current_doc+1);
		}
		return cp;
	}	
}