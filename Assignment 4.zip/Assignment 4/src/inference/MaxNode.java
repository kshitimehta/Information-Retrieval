package inference;

import java.util.ArrayList;

public class MaxNode extends BeliefNode {

	public MaxNode(ArrayList<? extends QueryNode> c){
		super(c);
	}
	
	public double score(int docId) {
		double score =0.0;
		double max =-10000000;
		for(int i=0;i<children.size();i++)
		{
			score = children.get(i).score(docId);		
			if(score > max) {
				max = score;
			}	
		}
		
		return max;	
	}
	
}
