package inference;

import java.util.ArrayList;
import java.lang.Math; 

public class OrNode extends BeliefNode {

	public OrNode(ArrayList<? extends QueryNode> children){
		super(children);
	}
	
	public double score(int docId) {
		double score =0.0;
		for(int i=0;i<children.size();i++)
		{
			score += 1- Math.exp(children.get(i).score(docId));			
		}
		
		return Math.log(1 - score);	
	}	
	
	
}