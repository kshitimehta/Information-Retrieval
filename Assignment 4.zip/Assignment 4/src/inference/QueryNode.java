package inference;


public interface QueryNode {

	
	public boolean hasMore();
	public int nextCandidate();
	public void skipTo(int docId);
	public double score(int docId);
	
	
}
