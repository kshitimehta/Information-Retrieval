package inference;

public class FilterRequire extends FilterOperator {

	public FilterRequire(ProximityNode pn, QueryNode queryNode) {
		super(pn,queryNode);
	}
	
	@Override
	public int nextCandidate() {
		return Math.max(filter.nextCandidate(),query.nextCandidate());
	}
	
	@Override
	public double score(int docId) {
		if(filter.p.getCurrentPosting().getDocId() == docId) {
			return query.score(docId);
		}
		else
			return -1.0;
	}
	
}
