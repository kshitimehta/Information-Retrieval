package apps;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import index.Index;
import index.InvertedIndex;
import retrieval.BM25;
import retrieval.Dirichlet;
import retrieval.JelinikMercer;
import retrieval.RetrievalModel;
import inference.TermNode;
import inference.OrderedWindow;
import inference.UnOrderedWindow;
import inference.ProximityNode;
import inference.BeliefNode;
import inference.AndNode;
import inference.InferenceNetwork;
import inference.MaxNode;
import inference.OrNode;
import inference.SumNode;
import inference.QueryNode;

public class TestInferenceNetwork {

	public static void main(String[] args) {

			int k = Integer.parseInt(args[0]);
			boolean compressed = Boolean.parseBoolean(args[1]);
			Index index = new InvertedIndex();
			index.load(compressed);
			
			RetrievalModel model = new Dirichlet(index,1500);
			List<Map.Entry<Integer, Double>> results;
			InferenceNetwork network = new InferenceNetwork();
			BeliefNode queryNode;
			ArrayList<ProximityNode> children = new ArrayList<>();
			
			String queryFile = args[2];
			List <String> queries = new ArrayList<String>();
			try {
				String query;
				BufferedReader reader = new BufferedReader(new FileReader(queryFile));
				while ((query = reader.readLine()) != null) {
					queries.add(query);
				}
				reader.close();
			} catch(Exception e) {
				e.printStackTrace();
			}
			
			
			String runid = "kdmehta-dir-1500";
			String outputFile = "or.trecrun";
					
			
			int qNum = 0;

			for (String query: queries) {
				
				qNum++;
				children = genTermNodes(query,model,index);
				//System.out.println("Here1");
				queryNode = new OrNode(children);
				//System.out.println("Here2");
				results = network.runQuery(queryNode, k);
				//System.out.println("Here3");
				boolean append = qNum>1;
				try {
					PrintWriter writer = new PrintWriter(new FileWriter(outputFile,append));
					for (Map.Entry<Integer, Double> result: results) {
						writer.println("Q" + qNum + "\t" + index.getDocName(result.getKey()) + "\t" + result.getValue() + "\t" + runid);
					}
					writer.close();
					//System.out.println("Here4");
				}catch (Exception e)
				{
					e.printStackTrace();
				}
			}
			
			outputFile = "and.trecrun";
			qNum = 0;
			
			for (String query: queries) {

				qNum++;		
				children = genTermNodes(query,model,index);
				//System.out.println("Here1");
				queryNode = new AndNode(children);
				//System.out.println("Here2");
				results = network.runQuery(queryNode, k);
				boolean append = qNum>1;
				
				try {
					PrintWriter writer = new PrintWriter(new FileWriter(outputFile,append));
					for (Map.Entry<Integer, Double> result: results) {
						writer.println("Q" + qNum + "\t" + index.getDocName(result.getKey()) + "\t" + result.getValue() + "\t" + runid);
						
					}
					writer.close();
					//System.out.println("Here3");
				}
				catch (Exception e)
				{
					e.printStackTrace();
				}
			}	
			
			outputFile = "max.trecrun";
			qNum = 0;
			
			for (String query: queries) {

				qNum++;		
				children = genTermNodes(query,model,index);
				queryNode = new MaxNode(children);
				results = network.runQuery(queryNode, k);
				boolean append = qNum>1;
				
				try {
					PrintWriter writer = new PrintWriter(new FileWriter(outputFile,append));
					for (Map.Entry<Integer, Double> result: results) {
						writer.println("Q" + qNum + "\t" + index.getDocName(result.getKey()) + "\t" + result.getValue() + "\t" + runid);
					}
					writer.close();
				}catch (Exception e)
				{
					e.printStackTrace();
				}
				}
			
			
			outputFile = "sum.trecrun";
			qNum = 1;
			
			for (String query: queries) {

				qNum++;		
				children = genTermNodes(query,model,index);
				queryNode = new SumNode(children);
				results = network.runQuery(queryNode, k);
				boolean append = qNum>1;
				
				try {
					PrintWriter writer = new PrintWriter(new FileWriter(outputFile,append));
					for (Map.Entry<Integer, Double> result: results) {
						writer.println("Q" + qNum + "\t" + index.getDocName(result.getKey()) + "\t" + result.getValue() + "\t" + runid);
					}
					writer.close();
				}catch (Exception e)
				{
					e.printStackTrace();
				}
				}			
			outputFile = "od1.trecrun";
			qNum = 0;
			QueryNode QueryNode;
			
			for (String query: queries) {

				qNum++;		
				children = genTermNodes(query,model,index);
				QueryNode = new OrderedWindow(1, children, index, model);
				results = network.runQuery(QueryNode, k);
				boolean append = qNum>1;
				
				try {
					int rank =1;
					PrintWriter writer = new PrintWriter(new FileWriter(outputFile,append));
					for (Map.Entry<Integer, Double> result: results) {
						writer.println("Q" + qNum + "\t" + index.getDocName(result.getKey()) + "\t" +rank+"\t"+ result.getValue() + "\t" + runid);
						rank++;
					}
				}catch (Exception e)
				{
					e.printStackTrace();
				}
				}
			
			outputFile = "uw.trecrun";
			qNum = 0;
			
			
			for (String query: queries) {

				qNum++;		
				children = genTermNodes(query,model,index);
				QueryNode = new UnOrderedWindow(1, children, index, model);
				results = network.runQuery(QueryNode, k);
				boolean append = qNum>1;
				
				try {
					int rank =1;
					PrintWriter writer = new PrintWriter(new FileWriter(outputFile,append));
					for (Map.Entry<Integer, Double> result: results) {
						writer.println("Q" + qNum + "\t" + index.getDocName(result.getKey()) + "\t" +rank+"\t"+ result.getValue() + "\t" + runid);
						rank++;
					}
				}catch (Exception e)
				{
					e.printStackTrace();
				}
				}
			
		
	}
	
	public static ArrayList<ProximityNode> genTermNodes(String query,RetrievalModel model,Index index){
		ArrayList<ProximityNode> children = new ArrayList<ProximityNode>();
		String[] terms = query.split("\\s+");
		for(String term:terms)
		{	ProximityNode x =  new TermNode(term,index,model);
			children.add(x);
		}
		
		return children;
	}
}
