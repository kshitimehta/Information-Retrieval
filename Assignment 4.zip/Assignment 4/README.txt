README

- This project was created in NetBeans.
- Dependencies used : json-simple.1.1 jar
- Import the src/* file into NetBeans with project named Indexer.
-Download the dependency 
- Add Jar file to the project by right clicking the project > select properties > Libraries > Add JAR/Folder > Select the downloaded dependency
- Build Project by selecting Run> Clean and Build Project
_ Run the class TestInferenceNetwork as it is the main class and all the other methods and classes are called from there on. (fn F6 in Mac)
- The output will give you the results for the 6 trecruns.
