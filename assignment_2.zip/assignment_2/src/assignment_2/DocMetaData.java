package assignment_2;

public class DocMetaData {
	
	int doc_id = -1;
	String scene_name = "";
	String play_name = "";
	int scene_length = -1;
	
	
	DocMetaData(){};
	DocMetaData(int doc_id,String play_name,String scene_name,int scene_length)
	{
		this.doc_id = doc_id;
		this.scene_name = scene_name;
		this.play_name = play_name;
		this.scene_length = scene_length;
	}
	
}

