package assignment_2;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;


public class Evaluation {
	
	
	Evaluation(){};
	// cross check compressed and uncompressed data

	public HashMap<String,ArrayList<String>> comparingRetrievalModels(Indexer indexerObject,int noOfResults,String dataFile,String lookupTableFile,int noOfDocuments,ArrayList<String> queries,boolean compressedFlag)
	{
        Retrieval bot = new Retrieval();
        Indexer indexObject = indexerObject;
        HashMap<String, int[]> lookUpTable = null;
        
        try {

            lookUpTable = indexObject.readLookuptable(lookupTableFile);
        	
            }
            catch(Exception e)
            {
            	e.printStackTrace();
            }
        int topic = 1;
        HashMap<String,ArrayList<String>> evaluation = new HashMap<String,ArrayList<String>>();
        ArrayList<String> BM25All = new ArrayList<String>();
        ArrayList<String> QLJMAll = new ArrayList<String>();
        ArrayList<String> QLDIRAll = new ArrayList<String>();
        
        for(String query:queries)
        {
        	//PriorityQueue<Map.Entry<Integer,Double>> scores =         	
            ArrayList<String> BM25query =bot.documentAtATimeStringBM25(noOfDocuments, lookUpTable, indexObject, query, noOfResults,compressedFlag, dataFile,topic);
            ArrayList<String> QLJMquery =bot.documentAtATimeStringJelenikMercer(noOfDocuments, lookUpTable, indexObject, query, noOfResults,compressedFlag, dataFile,topic);
            ArrayList<String> QLDIRquery =bot.documentAtATimeStringDirichlet(noOfDocuments, lookUpTable, indexObject, query, noOfResults,compressedFlag, dataFile,topic);
            BM25All.addAll(BM25query);
            QLJMAll.addAll(QLJMquery);
            QLDIRAll.addAll(QLDIRquery);
            
            topic += 1;
        }
        evaluation.put("bm25.trecrun",BM25All);
        evaluation.put("ql-jm.trecrun",QLJMAll);
        evaluation.put("ql-dir.trecrun",QLDIRAll);
        return evaluation;
	}
	
}	


