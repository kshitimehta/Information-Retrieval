package assignment_2;


import java.util.Map.Entry;
import java.util.AbstractMap;
import java.util.*;

import java.lang.Math;
public class Retrieval {
  
  int score;
  
 public Retrieval()
  {
  this.score = 0;
  }
 
  
  
  private double BM25Score(int tf,int qtf,int dl,int df,int N,double avdl)
  {	
	  double tfd =tf;
	  double qtfd =qtf;
	  double dld =dl;
	  double dfd =df;
	  double Nd =N;
	  
	  double k1 = 1.2;
	  double k2 = 100;
	  double b = 0.75;
	  
	  double score=0.0;
	  
	  double K = k1*((1-b)+((b*dld)/avdl));
	  double idf = Math.log((Nd-dfd+0.5)/(dfd+0.5));
	  double tf_score = ((k1+1)*tfd)/(K+tfd);
	  double qf_score = (k2+1)*qtfd/(k2+qtfd);
	  score = idf*tf_score*qf_score;
	  
	  return score;
  }
  
  private double JelenikMercerSmootheningScore(int tf,int ctf,int dl,int df,int ctl)
  {
	  double lambda = 0.1;
	  double tfd = tf;
	  double dld = dl;
	  double ctfd = ctf;
	  double ctld = ctl;
	  
	  double score=0.0;
	  // query likelihood for document 
	  double qLD = (1-lambda)*tfd/dld;
	  double qLC = lambda*ctfd/ctld;
	  score = Math.log(qLD+qLC);
	  
	  return score;
  }
  private double DirichletSmootheningScore(int tf,int ctf,int dl,int df,int ctl,double avdl)
  {
	  double tfd = tf;
	  double mu = 2000.0;
	  double ctfd = ctf;
	  double ctld = ctl;
	  double dld = dl;
	  double score=0.0;
	  double num = tfd+ mu*(ctfd/ctld);
	  double denum = dld+mu;
	  
	  score = Math.log(num/denum);
	  
	  return score;
  }  
  
  private  ArrayList<String> printScoresTREC(PriorityQueue<Map.Entry<Integer,Double>> score_q,HashMap<Integer,DocMetaData> metaData,int q_ix,String runTag)
  {
      System.out.println("Printing TREC Format");
      int k = score_q.size();
      ArrayList<Entry<Integer,Double>> data = new ArrayList<Entry<Integer,Double>>();
      ArrayList<String> dataTREC = new ArrayList<String>();
      while(k > 0)
      {
    	  Map.Entry<Integer, Double> val = score_q.poll();
      	  data.add(val);
          //System.out.println(val.getKey() + ":" + val.getValue()+" ");
          k--;
      }
      Collections.reverse(data);
      int rank = 1;
      for(Entry<Integer, Double> e:data)
      {	  
    	  String x = "";
    	  x += q_ix+" ";
    	  x += "skip ";
    	  x += metaData.get(e.getKey()).scene_name + " ";
    	  x += String.valueOf(rank)+" ";   	  
    	  x += String.valueOf(-1*e.getValue())+ " ";
    	  
    	  x += runTag + "\n";
    	  dataTREC.add(x);
    	  rank += 1;
      }
      return dataTREC;
  }
  
  //retrieve data document at a time		
 
  // retrieve data document at a time from memory
  public ArrayList<String> documentAtATimeStringBM25(int last_id,HashMap<String,int[]> mapx,Indexer x, String query,int k,boolean compressedFlag,String IndexFileName,int q_ix)
  {  
	  PriorityQueue<Map.Entry<Integer,Double>>R =   new PriorityQueue<Map.Entry<Integer, Double>>(
              new Comparator<Map.Entry<Integer, Double>>()
              {
            	  @Override
                  public int compare(Entry<Integer, Double> v1, Entry<Integer, Double> v2) {
                      if (v1.getValue() > v2.getValue()) {
                          return -1;
                      } else if (v1.getValue() < v2.getValue()) {
                          return 1;
                      }
                      return 0;
                  }
              });
	  ArrayList<PostingsList> array = new ArrayList<PostingsList>();
	  String[] tokens = query.split("\\s+");
	  HashMap<String,Integer> termCounter = new HashMap<String,Integer>();
	  ArrayList<Integer> valid_docs = new ArrayList<Integer>();
	  
	  for (String term:tokens)
	  {   
		  if(termCounter.containsKey(term))
		  {
			  int count =termCounter.get(term);
			  termCounter.put(term, count+1);
		  }	
		  else
		  {
			  if(mapx.containsKey(term))
			  {
				  int[] arr = mapx.get(term);
				  try
				  {
	
					  ArrayList<Postings> p_data = x.readFromDisk( IndexFileName , arr[1], arr[0], compressedFlag);			  
					  PostingsList p = new PostingsList(p_data,term,true);
					  array.add(p); 
					  for(Postings px:p.InvList)
					  {
						  if(!valid_docs.contains(px.doc_id))
						  {
							  valid_docs.add(px.doc_id);							  
						  }

					  }
	
				  }
				  catch(Exception e)
				  {
					  e.printStackTrace();
				  }	
				  
				  
			  }
			  else
			  {
				  PostingsList p = new PostingsList();
				  array.add(p);
			  }
			  termCounter.put(term, 1);
		  
		  }
		  
	  }
	  Collections.sort(valid_docs);
	  for(int doc_position:valid_docs)
	  {	 

		  double scorex= 0;		  
		  
		  for(PostingsList p:array)
			  //make arrangements for invList = null;	  
		  {	 

			  if (p.InvList.size()!=0 )
			  {
				  if(p.getCurrentDocument().doc_id == doc_position)
				  {		
					  int tf = p.getCurrentDocument().positions.size();

					  int df = p.InvList.size();
					  int qtf = termCounter.get(p.term);
					  int dl = x.docMData.get(doc_position).scene_length;
					  int N = last_id;
					  double avdl = x.totalWords/last_id;	

					  double score = this.BM25Score(tf, qtf, dl, df, N,avdl);
					  if(doc_position==2)
					  {
						System.out.println("2");
						System.out.println(score);
					  }
					  scorex += score;

					  
				  }
				  boolean val = p.movePastDocument(doc_position);
				  if(val == false)
				  {
					  continue;
				  }
				  
			  }

		  }
		  if(scorex != 0.0)
		  {
		  Map.Entry<Integer,Double> entry =new AbstractMap.SimpleEntry<Integer,  Double>(doc_position,-1*scorex);
		  R.offer(entry);
		  if (R.size()>k)
		  {
			  R.poll();
		  }
		  }
	  }
		 String runTag = "KShubhankar-bm25";
		 return this.printScoresTREC(R,x.docMData,q_ix,runTag);  } 
  
  public ArrayList<String> documentAtATimeStringJelenikMercer(int last_id,HashMap<String,int[]> mapx,Indexer x, String query,int k,boolean compressedFlag,String IndexFileName,int q_ix)
  {  
	  PriorityQueue<Map.Entry<Integer,Double>>R =   new PriorityQueue<Map.Entry<Integer, Double>>(
              new Comparator<Map.Entry<Integer, Double>>()
              {
            	  @Override
                  public int compare(Entry<Integer, Double> v1, Entry<Integer, Double> v2) {
                      if (v1.getValue() > v2.getValue()) {
                          return -1;
                      } else if (v1.getValue() < v2.getValue()) {
                          return 1;
                      }
                      return 0;
                  }
              });
	  ArrayList<PostingsList> array = new ArrayList<PostingsList>();
	  String[] tokens = query.split("\\s+");
	  HashMap<String,Integer> termCounter = new HashMap<String,Integer>();
	  HashMap<String,Integer> totalTermCounter = new HashMap<String,Integer>();
	  ArrayList<Integer> valid_docs = new ArrayList<Integer>();
	  for (String term:tokens)
	  { 
		  if(termCounter.containsKey(term))
		  {
			  int count =termCounter.get(term);
			  termCounter.put(term, count+1);
		  }	
		  else
		  {
		  //handling oov
			  if(mapx.containsKey(term))
			  {
				  int[] arr = mapx.get(term);
				  try
				  {
	
					  ArrayList<Postings> p_data = x.readFromDisk( IndexFileName , arr[1], arr[0], compressedFlag);			  
					  PostingsList p = new PostingsList(p_data,term,true);
					  array.add(p);
					  int ctf = 0;
					  for(Postings px: p.InvList)
					  {
						  ctf += px.positions.size();
						  valid_docs.add(px.doc_id);
					  }
					  totalTermCounter.put(term, ctf);
	
				  }
				  catch(Exception e)
				  {
					  e.printStackTrace();
				  }			  
			  }
			  else
			  {
				  PostingsList p = new PostingsList();
				  p.term = term;
				  array.add(p);
				  totalTermCounter.put(term, 0);
			  }

		  
		  }
		  
	  }
	  
	  Collections.sort(valid_docs);	  
	  for(int doc_position = 1;doc_position<last_id;doc_position++)
	  {	 
		  double scorex= 0;		  
		  
		  for(PostingsList p:array)

			  //make arrangements for invList = null;
		  {	 
			  if (p.InvList.size()!=0 )
			  {
				  if(p.getCurrentDocument().doc_id == doc_position)
				  {		
					  int tf = p.getCurrentDocument().positions.size();
					  int df = p.InvList.size();
					  int dl = x.docMData.get(doc_position).scene_length;
					  int ctl = x.totalWords;
					  int ctf = totalTermCounter.get(p.term);
					  scorex += this.JelenikMercerSmootheningScore(tf, ctf, dl, df, ctl);
				  }
				  else
				  {
					  int df = p.InvList.size();
					  int dl = x.docMData.get(doc_position).scene_length;
					  int ctl = x.totalWords;
					  int ctf = totalTermCounter.get(p.term);
					  scorex += this.JelenikMercerSmootheningScore(0, ctf, dl, df, ctl);
					  
				  }
				  boolean val = p.movePastDocument(doc_position);
				  if(val == false)
				  {
					  continue;
				  }
			  }
			  else
			  {
				 int ctf = totalTermCounter.get(p.term);
				 scorex += 0.5/ctf; 
			  }
		  }
		 
		  Map.Entry<Integer,Double> entry =new AbstractMap.SimpleEntry<Integer,  Double>(doc_position,-1*scorex);
		  R.offer(entry);
		  if (R.size()>k)
		  {
			  R.poll();
		  }
	  }
		 String runTag = "KShubhankar-ql-jm";
		 return this.printScoresTREC(R,x.docMData,q_ix,runTag);
  }   

  public ArrayList<String> documentAtATimeStringDirichlet(int last_id,HashMap<String,int[]> mapx,Indexer x, String query,int k,boolean compressedFlag,String IndexFileName,int q_ix)
  {  
	  PriorityQueue<Map.Entry<Integer,Double>>R =   new PriorityQueue<Map.Entry<Integer, Double>>(
              new Comparator<Map.Entry<Integer, Double>>()
              {
            	  @Override
                  public int compare(Entry<Integer, Double> v1, Entry<Integer, Double> v2) {
                      if (v1.getValue() > v2.getValue()) {
                          return -1;
                      } else if (v1.getValue() < v2.getValue()) {
                          return 1;
                      }
                      return 0;
                  }
              });
	  ArrayList<PostingsList> array = new ArrayList<PostingsList>();
	  String[] tokens = query.split("\\s+");
	  HashMap<String,Integer> termCounter = new HashMap<String,Integer>();
	  HashMap<String,Integer> totalTermCounter = new HashMap<String,Integer>();
	  ArrayList<Integer> valid_docs = new ArrayList<Integer>();
	  for (String term:tokens)
	  { 
		  if(termCounter.containsKey(term))
		  {
			  int count =termCounter.get(term);
			  termCounter.put(term, count+1);
		  }	
		  else
		  {
		  //handling oov
			  if(mapx.containsKey(term))
			  {
				  int[] arr = mapx.get(term);
				  try
				  {
	
					  ArrayList<Postings> p_data = x.readFromDisk( IndexFileName , arr[1], arr[0], compressedFlag);			  
					  PostingsList p = new PostingsList(p_data,term,true);
					  array.add(p);
					  int ctf = 0;
					  for(Postings px: p.InvList)
					  {
						  ctf += px.count;
						  valid_docs.add(px.doc_id);
					  }
					  totalTermCounter.put(term, ctf);
	
				  }
				  catch(Exception e)
				  {
					  e.printStackTrace();
				  }			  
			  }
			  else
			  {
				  PostingsList p = new PostingsList();
				  p.term = term;
				  array.add(p);
				  totalTermCounter.put(term, 0);
			  }

		  
		  }
		  
	  }
	  
	  for(int doc_position = 1;doc_position<last_id;doc_position++)
	  {	 
		  double scorex= 0;		  
		  
		  for(PostingsList p:array)

			  //make arrangements for invList = null;
		  {	 
			  if (p.InvList.size()!=0 )
			  {
				  if(p.getCurrentDocument().doc_id == doc_position)
				  {		
					  int tf = p.getCurrentDocument().positions.size();
					  int df = p.InvList.size();
					  int dl = x.docMData.get(p.getCurrentDocument().doc_id).scene_length;
					  int ctl = x.totalWords;
					  int ctf = totalTermCounter.get(p.term);
					  double avdl = ctl/last_id;

					  scorex += this.DirichletSmootheningScore(tf, ctf, dl, df, ctl, avdl);
				  }
				  else
				  {
					  int df = p.InvList.size();
					  int dl = x.docMData.get(p.getCurrentDocument().doc_id).scene_length;
					  int ctl = x.totalWords;
					  int ctf = totalTermCounter.get(p.term);
					  double avdl = ctl/last_id;
				
					  scorex += this.DirichletSmootheningScore(0, ctf, dl, df, ctl, avdl);
					  
				  }
				  boolean val = p.movePastDocument(doc_position);
				  if(val == false)
				  {
					  continue;
				  }
			  }
			  else
			  {
				 int ctf = totalTermCounter.get(p.term);
				 scorex += 0.5/ctf; 
			  }
		  }
		 
		  Map.Entry<Integer,Double> entry =new AbstractMap.SimpleEntry<Integer,  Double>(doc_position,-1*scorex);
		  R.offer(entry);
		  if (R.size()>k)
		  {
			  R.poll();
		  }
	  }
	 String runTag = "KShubhankar-ql-dir";
	 return this.printScoresTREC(R,x.docMData,q_ix,runTag);
  }   

  
  
}
