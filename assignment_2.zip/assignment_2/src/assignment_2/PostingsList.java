package assignment_2;


import java.util.Iterator; 

import java.util.*;

public class PostingsList 
{

	ArrayList<Postings> InvList = new ArrayList<Postings>();
	ArrayList<Integer> uncompressedData = new ArrayList<Integer>();
	ArrayList<Integer> uncompressedDeltaData = new ArrayList<Integer>();
	int doc_id_position = 0; 
	boolean init_flag = false;
	
	Postings currentPosting;
    String term;
	Iterator<Postings> listIterator;
    
	PostingsList() {};
	
	// Initialize Posting List with known data.
	PostingsList(ArrayList<Postings> invList, String term, boolean init_flag) 
	{
		  this.InvList = invList;
		  this.term = term;
		  this.init_flag = true;
		  this.currentPosting = invList.get(0);
		  this.doc_id_position = this.currentPosting.doc_id;
		  this.listIterator = this.InvList.iterator();
	};
	// add data to posting list
	public void add(int doc_id,int pos) 


	{   boolean doc_exist_flag = false;
		if(this.InvList.size()>0) 
		{
			for (int p = 0,size = this.InvList.size();p<size;p++)
			{
				Postings posting = this.InvList.get(p);
				if(posting.doc_id == doc_id)
				{
					posting.add(pos);
					InvList.set(p, posting);
					doc_exist_flag = true;//not sure if this is necessary
					break;
			
				}
			}
		}	
		if(doc_exist_flag== false) 
			{   
				Postings pObjectNew = new Postings();
				pObjectNew.doc_id = doc_id;
				pObjectNew.add(pos);
				this.InvList.add(pObjectNew);
				if(this.init_flag==false)
				{
					this.doc_id_position = doc_id;
					this.currentPosting = pObjectNew;
					this.init_flag = true;
				}
			}	
		
		}
	// get Current Document
	public Postings getCurrentDocument()
	{
		 
		return this.currentPosting;
	}
	//move pointer to next position
	public boolean nextDocument()
	{  
		if(this.listIterator.hasNext())
		{	
			Postings p = this.listIterator.next();
			this.currentPosting = p;
			this.doc_id_position = p.doc_id;
			return true;
		}
		else
		{
			return false;
		}
		

		
	}
    // skip forward to given document id
	public boolean skipForwardToDocument(int d)
	{	
		
		while(this.doc_id_position<d)
		{
			boolean er = this.nextDocument();
			if(er == false)
			{
				return false;
			}
		}
		return true;
	}	
	// move past the given document
    public boolean movePastDocument(int d)
	{		
			if(this.doc_id_position==d)
			{
				this.nextDocument();
					
			}
			if(this.doc_id_position<d)
			{	
				while(this.doc_id_position<=d)
				{
					boolean x =this.nextDocument();
					if(x==false)
					{
						return false;
					}
			
				}
			}

	return true;			
	}
		
}
		

