package assignment_2;

import java.util.ArrayList;

import java.io.ByteArrayOutputStream;
public class Encoder {

	Encoder(){};
	
	public ArrayList<Integer> deltaEncoding(ArrayList<Integer> data)
	{
		ArrayList<Integer> deltaData = new ArrayList<Integer>(data.size());
		int current_delta_value = 0;
		int current_count_value = 0;
		int p = 0;
		while(p<data.size())
		{
			deltaData.add(p, data.get(p)-current_delta_value); //doc_id
			current_delta_value = data.get(p);
			p += 1;
			deltaData.add(p,data.get(p));
			current_count_value = data.get(p);
			p += 1;
			int current_position = 0;
			while(current_count_value>0)
			{   	
				deltaData.add(p,data.get(p)-current_position);
				current_position = data.get(p);
				p += 1;
				current_count_value -= 1;
			}
		}
		return deltaData;
	}
	
	public ArrayList<Postings> deltaDecoding(ArrayList<Integer> data)
	{
		int p =0;
		int last_d = 0;
		ArrayList<Postings> PList = new ArrayList<Postings>();
		while(p<data.size())
		{	
			Postings pd = new Postings();
			pd.doc_id = data.get(p)+last_d;
			p += 1;
			pd.count = data.get(p);
			ArrayList<Integer> p_list = new ArrayList<Integer>();
			int count = 0;
			int last_p = 0;
			if(pd.count>0)
			{
				p+=1;			
			}
			while (count<pd.count)
			{	
				int e = data.get(p)+last_p;
				p_list.add(e); 
				count += 1;
				last_p = e;
				p+=1;
			}
			
			pd.positions = p_list;
			last_d = pd.doc_id;
			PList.add(pd);
			
		}
		return PList;
	}
	
	public ArrayList<Integer> deltaDecodingFaster(ArrayList<Integer> data)
	{
		int p =0;
		int last_d = 0;
		ArrayList<Integer> pList = new ArrayList<Integer>();
		while(p<data.size())
		{	

			pList.add(data.get(p)+last_d);
			last_d = data.get(p)+last_d;			
			p += 1;
			pList.add(data.get(p));
			int pos = data.get(p);
			int count = 0;
			int last_p = 0;
			if(pos>0)
			{
				p+=1;			
			}
			while (count<pos)
			{	
				pList.add(data.get(p)+last_p);
				int e = data.get(p)+last_p;
				count += 1;
				last_p = e;
				p+=1;
			}
			
		}
		return pList;
	}
	
	public ArrayList<Postings> normalDecoding(ArrayList<Integer> data)
	{
		int p =0;
		//int last_d = 0;
		ArrayList<Postings> PList = new ArrayList<Postings>();
		while(p<data.size())
		{	
			Postings pd = new Postings();
			pd.doc_id = data.get(p);//+last_d;
			p += 1;
			pd.count = data.get(p);
			ArrayList<Integer> p_list = new ArrayList<Integer>();
			int count = 0;
			p+=1;			
			//int last_p = 0;
			while (count<pd.count)
			{

				int e = data.get(p);//+last_p;
				p_list.add(e); 
				count += 1;
				p+= 1;
				//last_p = e;
			}
			
			pd.positions = p_list;
			//last_d = pd.doc_id;
			PList.add(pd);
			
		}
		return PList;
	}
	
	
	public byte[] vbyteEncoding(int[] data)
	{	ByteArrayOutputStream result = new ByteArrayOutputStream(); 
		//ByteBuffer output = ByteBuffer.allocate(data.length*4);
		for(int i:data)
		{
		while(i>=128)
		{
			result.write((byte)i & 0x7F);
			i>>>=7;
			
		}
		result.write((byte)i|0x80);
		}
		byte [] output = result.toByteArray();
		return output;

	}
	
	public ArrayList<Integer> vbyteDecoder(byte [] input)
	{
		ArrayList<Integer> output = new ArrayList<Integer>();
		int i =0;
		while(i < input.length)
		{
			int position = 0;
			int result = ((int) input[i] & 0x7F);
			while ((input[i] & 0x80) ==0)
			{
				i +=1;
				position += 1;
				int unsignedByte = ((int) input[i] & 0x7F);
				result |= (unsignedByte <<(7*position));
				
			}
			output.add(result);
			i++;
		}
		return output;
		
	}

}
