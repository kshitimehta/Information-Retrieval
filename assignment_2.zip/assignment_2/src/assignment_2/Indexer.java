package assignment_2;


import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

import org.json.simple.JSONArray; 
import org.json.simple.JSONObject; 
import org.json.simple.parser.*; 

import java.util.*;


import java.io.RandomAccessFile;
import java.nio.ByteBuffer;
import java.math.BigInteger;
import java.io.FileWriter;
import java.io.BufferedReader;

public class Indexer
{
	
	HashMap<String,PostingsList> List_x;
	int minSceneLength;
	int maxSceneLength;
	int maxPlayLength;
	int minPlayLength;
	String minPlayName;		
	String maxPlayName;		
	String maxSceneName;
	String minSceneName;
	int noOfPlays = 0;
	int totalWords = 0;	
	int noOfScenes = 0;
	HashMap<Integer,DocMetaData> docMData = new HashMap<Integer,DocMetaData>();
	String[] vocabulary; 
	Indexer()
	{
		this.List_x = new HashMap<String,PostingsList>();
	};
	//create inverted list
	public int creatingInvList( JSONArray data_x )
	{
		
		 //= new HashMap<String,ArrayList<Postings>>();
		int minSceneLength = 100000;
		int maxSceneLength = 0;
		int maxPlayLength = 0;
		int minPlayLength = 100000;
		String minPlayName = "";		
		String maxPlayName = "";		
		String maxSceneName = "";
		String minSceneName = "";
		int totalWords = 0;	
		int no_of_docs;
		int medPlaySize = 0;
		String prevPlayId = "";		
		boolean initFlag = true;
		int pByScene = 0;
		int minpByScene = 100000;
		int maxpByScene = 0;

        for (int i=0, size= data_x.size(); i<size; i++) 
        {       	
        	this.noOfScenes += 1;
        	JSONObject x = (JSONObject)  data_x.get(i);
        	String sceneText = (String) x.get("text");
        	String[] tokens = sceneText.split("\\s+");
        	String playId = (String) x.get("playId");
        	String sceneId = (String) x.get("sceneId");
        	DocMetaData md = new DocMetaData(i+1,playId,sceneId,tokens.length);
        	this.docMData.put(i+1,md);
        	
        	//statistics 
        	
        	totalWords += tokens.length;
        	if(initFlag)
        	{
        		medPlaySize = tokens.length;
        		prevPlayId = playId;
        		initFlag = false;
        		pByScene = 1;
        		
        	}
        	else
        	{
            	
                if(playId.equals(prevPlayId))            		
            	{
            		medPlaySize += tokens.length;
            		pByScene += 1;
            	}
                else
            	{	this.noOfPlays += 1;
                	if(medPlaySize>maxPlayLength)
                	{
                		maxPlayLength = medPlaySize;
                		maxPlayName = prevPlayId;
                		maxpByScene = pByScene;

                	}
                	if(medPlaySize<minPlayLength)
                	{
                		minPlayLength = medPlaySize;
                		minPlayName = prevPlayId;
                		minpByScene = pByScene;
                		
                	}      		
            		medPlaySize = tokens.length;
            		prevPlayId = playId;
            		pByScene = 1;
            		
            	}

        		
        	}
        	if(tokens.length>maxSceneLength)
        	{
        		maxSceneLength = tokens.length;
        		maxSceneName = sceneId;
        	}
        	if(tokens.length<minSceneLength)
        	{
        		minSceneLength = tokens.length;
        		minSceneName = sceneId;
        	}
        	
        	
        	
        	int doc_id = i+1;
        	 
        	
        	for (int j = 0,length = tokens.length;j<length;j++) 
        	{ 	
        		
        		//System.out.println(tokens[j]);		
        		if(this.List_x.containsKey(tokens[j])) 
        		{    
        			PostingsList postingList = this.List_x.get(tokens[j]);
        			postingList.add(doc_id, j+1);
        			this.List_x.put(tokens[j], postingList);
        			
        			
          		}
        		else
        		{
        			PostingsList postingList = new PostingsList();
        			postingList.term = tokens[j];
        			postingList.add(doc_id, j+1);
        			this.List_x.put(tokens[j], postingList);
        			
        			
        		}
        		
        		
        	}
        	
           
        }

        this.maxPlayLength = maxPlayLength;
        this.minPlayLength = minPlayLength;
        this.maxSceneLength = maxSceneLength;
        this.minSceneLength = minSceneLength;
        this.minSceneName = minSceneName;
        this.maxSceneName = maxSceneName;
        this.maxPlayName = maxPlayName;
        this.minPlayName = minPlayName;
        
        this.vocabulary = this.List_x.keySet().toArray(new String[List_x.size()]);
        this.totalWords = totalWords;
        return data_x.size();
	}
	// write data to disk
	public HashMap<String,int[]> writeToDisk(String x,boolean compressedFlag) throws FileNotFoundException, IOException, ParseException
	{	
		Set<String> Keys = this.List_x.keySet();
		Encoder encoder = new Encoder();
		HashMap<String,int[]> key_offset_pairs = new HashMap<String,int[]>();
		RandomAccessFile invListWriter = new RandomAccessFile(x,"rw");     
		long offset1 = (long) 0;
		
        for(String key: Keys)
        {	
        	int [] offsets = new int[4]; 
        	offsets[0] = (int)offset1;
        	PostingsList posting = this.List_x.get(key);
    		ArrayList<Integer> uncompressed_data = new ArrayList<Integer>(); 
    		//System.out.println(key);
        	int count_term_frequency = 0;
            int document_frequency = posting.InvList.size();
        	for(int p=0,size=posting.InvList.size();p<size;p++)
        	{	
        		
        		uncompressed_data.add(posting.InvList.get(p).doc_id);

        		uncompressed_data.add(posting.InvList.get(p).count);
        		count_term_frequency +=posting.InvList.get(p).positions.size();
        		for(int p_id = 0;p_id<posting.InvList.get(p).positions.size();p_id++)
        		{
        			uncompressed_data.add(posting.InvList.get(p).positions.get(p_id));      			
        		}
        		
        	}
        	posting.uncompressedData = uncompressed_data;

        	if(compressedFlag == true) 
        	{
        	posting.uncompressedDeltaData = encoder.deltaEncoding(uncompressed_data);
        	int[] data = new int[posting.uncompressedDeltaData.size()];
        	for(int i = 0;i<data.length;i++)
        	{
        		data[i] = posting.uncompressedDeltaData.get(i);
        	}
        	posting.uncompressedData = null;
    		byte [] array_d = encoder.vbyteEncoding(data);
    		invListWriter.write(array_d);
        	offset1 = invListWriter.getFilePointer();
        	offsets[1] = (int) offset1 - offsets[0];
        	
        	}
        	else
        	{
            	int[] data = new int[posting.uncompressedData.size()];
            	ByteBuffer byteBuffer = ByteBuffer.allocate(data.length *4);
        		for(int i = 0;i<data.length;i++)
            	{
            		data[i] = posting.uncompressedData.get(i); 
            		byteBuffer.putInt(data[i]);
            	}	
        		posting.uncompressedDeltaData = null;
        		byte[] array_u = byteBuffer.array();
        		invListWriter.write(array_u);
            	offset1 = invListWriter.getFilePointer();
            	offsets[1] = (int) offset1 - offsets[0];
        		
        		
        	}
        	offsets[2] = count_term_frequency;
        	offsets[3] = document_frequency;
        	key_offset_pairs.put(key, offsets);
	
        	
        }
    	invListWriter.close();
        
        JSONObject json = new JSONObject();
        json.putAll(key_offset_pairs);
        json.toJSONString();
        invListWriter.close();
        return key_offset_pairs;			
	}
	// read data from disk
	public ArrayList<Postings> readFromDisk(String x,int buffLengthx,int offsetx,boolean compressedFlag) throws FileNotFoundException,IOException
	{	
		RandomAccessFile reader = new RandomAccessFile(x,"rw");
		ArrayList<Integer> intList = new ArrayList<Integer>();
		int offset = offsetx;
		int buffLength = buffLengthx;
		byte[] buffer = new byte[buffLength];
		reader.seek(offset);
		reader.read(buffer,0,buffLength);	
		ArrayList<Postings> p = new ArrayList<Postings>();
		Encoder encoder = new Encoder();	
		reader.close();
		
		if(compressedFlag ==true)
		{
		intList = encoder.vbyteDecoder(buffer);
    	p = encoder.deltaDecoding(intList);
		}
		else
		{	

			int off = 0;
			//System.out.println(buffLength);
			while(off<buffLength)
			{
				int docId = new BigInteger((Arrays.copyOfRange(buffer, off,off+4))).intValue();
				intList.add(docId);
				off += 4;
				int tf = new BigInteger((Arrays.copyOfRange(buffer, off,off+4))).intValue();
				intList.add(tf);

				off += 4;
				for(int i=0;i<tf;i++)
				{
					int pos = new BigInteger((Arrays.copyOfRange(buffer, off,off+4))).intValue();
					intList.add(pos);

					off += 4;
				}
			}
	    	p = encoder.normalDecoding(intList);
			
		}
				
		return p;
		
		
	}
	// read data from disk
	public ArrayList<Integer> readFromDiskFaster(String x,int buffLengthx,int offsetx,boolean compressedFlag) throws FileNotFoundException,IOException
	{	
		RandomAccessFile reader = new RandomAccessFile(x,"rw");
		ArrayList<Integer> intList = new ArrayList<Integer>();
		int offset = offsetx;
		int buffLength = buffLengthx;
		byte[] buffer = new byte[buffLength];
		reader.seek(offset);
		reader.read(buffer,0,buffLength);	
		ArrayList<Integer> p = new ArrayList<Integer>();
		Encoder encoder = new Encoder();	
		reader.close();
		if(compressedFlag ==true)
		{
		intList = encoder.vbyteDecoder(buffer);
    	p = encoder.deltaDecodingFaster(intList);
		}
		else
		{	

			int off = 0;
			while(off<buffLength)
			{
				int docId = new BigInteger((Arrays.copyOfRange(buffer, off,off+4))).intValue();
				intList.add(docId);
				off += 4;
				int tf = new BigInteger((Arrays.copyOfRange(buffer, off,off+4))).intValue();
				intList.add(tf);

				off += 4;
				for(int i=0;i<tf;i++)
				{
					int pos = new BigInteger((Arrays.copyOfRange(buffer, off,off+4))).intValue();
					intList.add(pos);

					off += 4;
				}
			}
			p = intList;
			
		}
				
		return p;
		
	}
	// write lookup table
	public void writeLookuptable(HashMap<String,int[] >table,String fileName) throws IOException
	{
		FileWriter fw=new FileWriter(fileName);
		String[] vocab =(String[]) table.keySet().toArray(new String[table.size()]);
		for(String v:vocab)
		{
		 int[] data = table.get(v);
		 fw.write(v+"\t");
		 for(int i:data)
		 {
			 String x = String.valueOf(i);
			 fw.write(x+"\t");
		 }
		 fw.write("\n");
		}
		fw.close();
		
		
	}
	// read lookup table
	public HashMap<String,int[]> readLookuptable(String fileName) throws IOException
	{

		
		
		HashMap<String,int[]> table = new HashMap<String,int[]>();
		String data;		
		
		FileReader fr=new FileReader(fileName);

		BufferedReader reader = new BufferedReader(fr);

		while((data = reader.readLine())!=null)
		{
			int[] arr_x = new int[4];
			String[] d = data.split("\\t+");
			String word = d[0];
			arr_x[0] = Integer.parseInt(d[1]);
			arr_x[1] = Integer.parseInt(d[2]);
			arr_x[2] = Integer.parseInt(d[3]);
			arr_x[3] = Integer.parseInt(d[4]);
			table.put(word, arr_x);
		}
		
		reader.close();
		fr.close();
		return table;
	}
	//  write query table to disk
	// return longest scene
	public String[] maxScene()
	{
		String[] maxScene = new String[2];
		maxScene[0] = this.maxSceneName;
		maxScene[1] = String.valueOf(this.maxSceneLength);
		return maxScene;
	}
	// return shortest scene	
	public String[] minScene()
	{
		String[] minScene = new String[2];
		minScene[0] = this.minSceneName;
		minScene[1] = String.valueOf(this.minSceneLength);
		return minScene;
	}

	// return shortest play
	public String[] minPlay()
	{
		String[] minPlay = new String[2];
		minPlay[0] = this.minPlayName;
		minPlay[1] = String.valueOf(this.minPlayLength);
		return minPlay;
	}	

	// return longest play
	public String[] maxPlay()
	{
		String[] maxPlay = new String[2];
		maxPlay[0] = this.maxPlayName;
		maxPlay[1] = String.valueOf(this.maxPlayLength);
		return maxPlay;
	}	
	// return average length of play
	public double avgPlay()
	{
		double words=  this.totalWords;
		double docs = this.noOfPlays;		

		return words/docs;
	}	
	// return average length of scene
	public double avgScene()
	{
		double words=  this.totalWords;
		double docs = this.noOfScenes;		
		return words/docs;
	}		
	// return vocabulary
	public String[] getVocabulary()
	{
		return this.vocabulary;
	}			
}

