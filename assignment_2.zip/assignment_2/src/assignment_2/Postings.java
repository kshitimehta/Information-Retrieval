package assignment_2;

import java.util.ArrayList;

public class Postings {
	int doc_id = 0;
	int count = 0;
	
	ArrayList<Integer> positions = new ArrayList<Integer>();

	Postings() {};
	Postings(int doc_idx, ArrayList<Integer> position) 
	{

		this.doc_id = doc_idx;
		if(position != null) {
			this.positions = position ;
		//break;
		}
		this.count = this.positions.size();
		
    }
	
	public void add(int doc_id,int pos) {
		
		this.doc_id = doc_id;
		this.positions.add(pos);
		this.count +=1;
		
	}
	
	public void add(int pos) {
		
		this.positions.add(pos);
		this.count +=1;
		//System.out.println(count);
	}	
	
}