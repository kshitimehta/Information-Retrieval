package assignment_2;



import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

import java.util.HashMap;

import java.util.Map;


import org.json.simple.JSONArray; 
import org.json.simple.JSONObject; 
import org.json.simple.parser.*; 

public class MainReaderAndEvaluation {



	public static void main(String[] args) throws FileNotFoundException, IOException, ParseException 
	{
		// TODO Auto-generated method stub
		boolean compressedFlag = true;
		String[] argumentData = args;

		
		if(argumentData[0].contentEquals("true"))
		{	
			compressedFlag = true;
		}
		else
		{
			compressedFlag = false;

		}
		String path = "D:\\College\\cs546\\shakespeare-scenes.json";
		String uncompressedFile = "invertedIndexFull";
		String uncompressedLookUpTable = "invertedIndexTable";
		String compressedFile = "invertedIndexFullCompressed";
		String compressedLookUpTable= "invertedIndexTableCompressed";
		
		path = path.replace("\\", "/");
		System.out.println(path);
		File file=new File(path);
		if(file.exists())
			System.out.println("Data exists");
        Object obj = new JSONParser().parse(new FileReader(file)); 
        JSONObject jo = (JSONObject) obj; 
        JSONArray load = (JSONArray) jo.get("corpus");
        Indexer indexObject = new Indexer();
        int no_of_docs = indexObject.creatingInvList(load);
        load = null;
        
        
        if(compressedFlag == false)
        {
            HashMap<String,int[]> offset = indexObject.writeToDisk(uncompressedFile,false);
            indexObject.writeLookuptable(offset,uncompressedLookUpTable);
        	
        }
        else
        {
        HashMap<String,int[]> offset12 = indexObject.writeToDisk(compressedFile,true);
        indexObject.writeLookuptable(offset12,compressedLookUpTable);
        }
        indexObject.List_x = null; //deleting inverted Index from memory;
        
        System.out.println("************************************\n\n EVALUATION \n\n************************************");

        System.out.println("Adding queries to List.");
        Evaluation eval = new Evaluation();
        ArrayList<String> queries = new ArrayList<String>();
        queries.add("the king queen royalty");
        queries.add("servant guard soldier");
        queries.add("hope dream sleep");
        queries.add("ghost spirit");
        queries.add("fool jester player");
        queries.add("to be or not to be");
        queries.add("alas");
        queries.add("alas poor");
        queries.add("alas poor yorick");
        queries.add("antony strumpet");
        HashMap<String,ArrayList<String>> data = new HashMap<String,ArrayList<String>>();
        if(compressedFlag)
        {
        	int noOfResults = 10;
        	int noOfDocuments = no_of_docs;  
        	String dataFile = "invertedIndexFullCompressed";
        	String lookupTableFile = "invertedIndexTableCompressed";
        	data =eval.comparingRetrievalModels(indexObject, noOfResults, dataFile, lookupTableFile, noOfDocuments, queries,compressedFlag);
        }
        else
        {
        	int noOfResults = 10;
        	int noOfDocuments = no_of_docs;  
        	String dataFile = "invertedIndexFull";
        	String lookupTableFile = "invertedIndexTable";    	
        	data = eval.comparingRetrievalModels(indexObject, noOfResults, dataFile, lookupTableFile, noOfDocuments, queries,compressedFlag);
        	
        	
        }
        
        for(Map.Entry element:data.entrySet())
        {
        	String fileName = (String) element.getKey();
        	ArrayList<String> value = (ArrayList<String>) element.getValue();
			ArrayList<String> queryResults = value;
    		FileWriter fw=new FileWriter(fileName);
    		for(String qr: queryResults)
    		{
    		 fw.write(qr);    		
    		}
    		fw.close();
    	}        	
        
        
        
	}
	
 
}		


