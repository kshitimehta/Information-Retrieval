/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package indexer;
import indexer.Reader;
import static indexer.Reader.doc_id;
import indexer.MetaData;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Random;
import java.util.Set;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.util.Scanner;
import java.io.IOException;
import java.time.Duration;
import java.time.Instant;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.ParseException;

/**
 *
 * @author kshitimehta
 */
public class Indexer {
    HashMap<Integer,MetaData> docMData = new HashMap<Integer,MetaData>();
    String[] vocabulary; 
    HashMap<String,PostingsList> List;
	Indexer()
	{
		List = new HashMap<String,PostingsList>();
	}
    /**
     * @param args the command line arguments
     */
    public void createIL(JSONArray data)throws FileNotFoundException, IOException, ParseException, Exception {
        // TODO code application logic here
        
        WriteToDisk w = new WriteToDisk();
        ReadFromDisk r = new ReadFromDisk();
        int length=0;
        int doc_id = -1;
        double [] doc_lens = new double[data.size()];
        int tot_words=0;
        String [] tokens={};
        String [] scenesid = new String[data.size()] ;
        for (int s =0; s<data.size();s++)
         {
         JSONObject j = (JSONObject) data.get(s);
         //load.add(jo);
         //System.out.println("PlayId: " + j.get("playId"));
         String playId = (String) j.get("playId"); 
         
         String sceneId = (String) j.get("sceneId"); 
         //System.out.println("SceneId: " + j.get("sceneId"));
         
         Long sceneNum = (Long) j.get("sceneNum"); 
         //System.out.println("SceneNum: " + j.get("sceneNum"));
         
         String text = (String) j.get("text"); 
         //System.out.println("Text: " + j.get("text"));
         
         tokens = text.split("\\s+");
         length = tokens.length;
         doc_id++;
         doc_lens[s]=(double)length;
         scenesid[s] = sceneId;
         //MetaData md = new MetaData(s+1,playId,sceneId,tokens.length);
         //this.docMData.put(s+1,md);
         //for(int k=0;k<tokens.length;k++)
               //System.out.println("Tokens: " +tokens[k]);
         
        
        
        
        
        //System.out.println("Length of token for docid"+doc_id+"="+length);
        tot_words += tokens.length;
         for (int k = 0;k<length;k++) 
        	{ 	
                    if(List.containsKey(tokens[k])) 
        		{    
                            //System.out.println("hi if");
        		
                            PostingsList pl = List.get(tokens[k]);
        			pl.addpost(doc_id, k);
        			List.put(tokens[k], pl);
        			
        			
          		}
        		else
        		{
                            //System.out.println("hi else");
                            PostingsList pl = new PostingsList();
                            pl.addpost(doc_id, k);
                            List.put(tokens[k], pl);	
        		}
        		
        	//System.out.println(List.get(tokens[k]));	
                	
        	}
        // System.out.println(List);
        }
        float avgdl;
        avgdl = (float) List.size()/(float)doc_id+1;
        //System.out.println(tot_words);
        //System.out.println(doc_id);
        Scanner s = new Scanner (System.in);
        System.out.println("Menu: 1. BM25 \n 2. JM \n 3. Dirichlet");
        int choice = s.nextInt();
        switch (choice)
        {
            case 1 :
//            HashMap<String,int[]> offset = w.write(List,"/Users/kshitimehta/NetBeansProjects/Indexer/Files/invertedIndexFull",false);
             System.out.println("BM25");
             Scoring sd = new Scoring();
             sd.BMDAT(avgdl, tot_words, doc_lens, doc_id, List, scenesid);
//            //System.out.println(offset);
//            int[] word_offset = offset.get("scene");
//
//            int buffLength =word_offset[1];
//            int offset1 = word_offset[0];
//            //System.out.println(buffLength);
//            //System.out.println(offset1);        
//            r.readFromDisk("/Users/kshitimehta/NetBeansProjects/Indexer/Files/invertedIndexFull",buffLength,offset1,false);
//            //Instant start = Instant.now();
//            //ToCreate7WordQueries q = new ToCreate7WordQueries();
//            //q.S7Words(List,doc_id);
//            //Instant finish = Instant.now();
//            //long timeTaken = Duration.between(start, finish).toMillis();
//            //System.out.println("Total Time Taken For 7 Word Query in Uncompressed= "+timeTaken);
//            
            break;
            
            case 2:
//                HashMap<String,int[]> offset12 = w.write(List,"/Users/kshitimehta/NetBeansProjects/Indexer/Files/invertedIndexFullCompressed",true);
            System.out.println("JM Smoothing");
                JelinikMercer jm = new JelinikMercer();
             //System.out.print(doc_id);
            jm.qljm(tot_words,doc_lens, doc_id, List,scenesid);
//        
//                //System.out.println(offset12);
//                int[] word_offset1 = offset12.get("scene");
//
//        
//                int buffLength1 =word_offset1[1]-word_offset1[0];
//                int offset11 = word_offset1[1];
//                //System.out.println(buffLength1);
//                //System.out.println(offset11);        
//                r.readFromDisk("/Users/kshitimehta/NetBeansProjects/Indexer/Files/invertedIndexFullCompressed",buffLength1,offset11,true); 
//                //Instant now = Instant.now();
//                //ToCreate7WordQueries q2 = new ToCreate7WordQueries();
//                //q2.S7Words(List,doc_id);
//                //Instant end = Instant.now();
//                //long endtime = Duration.between(now, end).toMillis();
//                //System.out.println("Total Time Taken For 7 Word Query in Uncompressed= "+endtime);
                break;  
                
            case 3:
                System.out.println("Dirichlet Smoothing");
                Dirichlet d = new Dirichlet();
                d.qldm(tot_words,doc_lens, doc_id, List,scenesid);
                break;
            
            default:
                System.out.println("Please Enter either 1 or 2");
                break;
                
        }
        //HashMap<String,int[]> offset = w.write(List,"/Users/kshitimehta/NetBeansProjects/Indexer/Files/invertedIndexFull",false);
        
        //System.out.println(offset);
        //int[] word_offset = offset.get("scene");

        
        //int buffLength =word_offset[1];
        //int offset1 = word_offset[0];
        //System.out.println(buffLength);
        //System.out.println(offset1);        
        //r.readFromDisk("/Users/kshitimehta/NetBeansProjects/Indexer/Files/invertedIndexFull",buffLength,offset1,false);
        //HashMap<String,int[]> offset12 = w.write(List,"/Users/kshitimehta/NetBeansProjects/Indexer/Files/invertedIndexFullCompressed",true);
        
        //System.out.println(offset12);
        //int[] word_offset1 = offset12.get("scene");

        
        //int buffLength1 =word_offset1[1]-word_offset1[0];
        //int offset11 = word_offset1[1];
        //System.out.println(buffLength1);
        //System.out.println(offset11);        
        //r.readFromDisk("/Users/kshitimehta/NetBeansProjects/Indexer/Files/invertedIndexFullCompressed",buffLength1,offset11,true); 
        
       
        
    }
    
    
   
   
}
