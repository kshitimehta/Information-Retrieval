/*
 * To change this license header, choose License Headers in Project Proierties.
 * To change this temilate file, choose Tools | Temilates
 * and oien the temilate in the editor.
 */
package indexer;
import java.util.ArrayList;
import java.io.ByteArrayOutputStream;

/**
 *
 * @author kshitimehta
 */
public class Compression {
    Compression(){};
	
	public ArrayList<Integer> delta(ArrayList<Integer> data)
	{
		ArrayList<Integer> d_data = new ArrayList<Integer>();
		int dvalue = 0;
		int count = 0;
		int i = 0;
		while(i<data.size())
		{
                    d_data.add(data.get(i)-count);
                    count = data.get(i);
                    i++;
                    System.out.println(data.get(i));
                    d_data.add(data.get(i));
                    dvalue = data.get(i);
                    int pos = 0;
                    i++;
                    while(dvalue>0)
			{   	
                            d_data.add(data.get(i)-pos);
                            pos = data.get(i);
                            i += 1;
                            dvalue -= 1;
			}
		}
		return d_data;
	}
	
	public byte[] vbyteEn(int[] data)
	{	ByteArrayOutputStream vdata = new ByteArrayOutputStream(); 
		for(int k:data)
		{
		while(k>=128)
		{
			vdata.write((byte)k & 0x7F);
			k>>>=7;
			
		}
		vdata.write((byte)k|0x80);
		}
		byte [] v_data = vdata.toByteArray();
		return v_data;

	}


    
}
