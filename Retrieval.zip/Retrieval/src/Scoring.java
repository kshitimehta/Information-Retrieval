/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package indexer;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.AbstractMap;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.PriorityQueue;
import java.util.Random;
import java.util.Set;

/**
 *
 * @author kshitimehta
 */
public class Scoring {
    public void BMDAT(double avg_doc_length, int tot_words,double [] doc_len, int doc_length, HashMap<String,PostingsList>  List,String[] sceneids) throws IOException
    {
        String[] sceneid= sceneids;
        int k = 10;
        
        double ni = 0;
        int flag = 0;
        double fi = 0.0;
        int rank;
        double[] doc_lens = doc_len;
        int N=doc_length;
        //int maxf = -1;
        BufferedWriter outputWriter = null;
        outputWriter = new BufferedWriter(new FileWriter("/Users/kshitimehta/Desktop/FALL '19/Applied Info Retrieval 546/Retrieval/TrecFiles/bm25.trecrun"));

//        PriorityQueue<Map.Entry<Integer,Integer>>PQ =   new PriorityQueue<Map.Entry<Integer, Integer>>();
          
          //Indexer x = new Indexer();
        //int k = 2;
        //WriteToDisk w = new WriteToDisk();
        //int doc_length = x.List.size();
        
	//String[] tokens = query.split("\\s+");
        //System.out.println("Hi here" + doc_length);
	  //Set<String> tokens = x.List.keySet();
          
          
          String[] user_query = {"the king queen royalty" ,
                                "servant guard soldier" ,
                                "hope dream sleep", 
                                "ghost spirit" ,
                                "fool jester player" ,
                                "to be or not to be" ,
                                "alas" ,
                                "alas poor" ,
                                "alas poor yorick" ,
                                "antony strumpet"};
          
          for(int oj = 0;oj<user_query.length;oj++)
          {
            rank=0;
            k=10;
//            double max = -1000000000;
//            maxf=-1;
            String[] query_terms={};
            ArrayList<PostingsList> al = new ArrayList<PostingsList>();
            PriorityQueue<Map.Entry<Integer, Double>> PQ = new PriorityQueue<>
              (new Comparator<Map.Entry<Integer, Double>>()
              {
            	  @Override
                  public int compare(Entry<Integer, Double> v1, Entry<Integer, Double> v2) {
                      if (v1.getValue() > v2.getValue()) {
                          return 1;
                      } else if (v1.getValue() < v2.getValue()) {
                          return -1;
                      }
                      return 0;
                  }
              });
            query_terms = user_query[oj].split("\\s+"); 
              
          for (String term:query_terms)
	  {     
               
              PostingsList p = List.get(term);
              al.add(p);
              //System.out.println("Hi "+List.get(term));
	  }

                int qfi = query_terms.length;
		//int i,j;
                //int w = 0;
		//int len = user_query.length;
                //int lenu=user_query[w].length();	
		
		//double doc_score = 0.0;
		double k1 = 1.2; double k2 = 100; double b = 0.75;
		
                    
                    for (int f=0;f<doc_length;f++)
                    {
                        flag = 0;
                        double doc_score = 0.0;
                        double K = k1 * ( (1.0 - b) + b * (doc_lens[f] / avg_doc_length));
                    //int freq = 0;
                    //int ni=0;
              //System.out.println("Hi here " + doc_lens[f]);
              //System.out.println("Hi here " + );
                    for(PostingsList li:al)
                    {
                        ni = li.IL.size();
                 // System.out.println("Hi "+ni);
                      // ni=0;
                  for(Postings p: li.IL)
                   {
                       
                    fi=0;
                       
                    //System.out.println("This is the doc: "+pos.doc_id);
                    //System.out.println("Hi "+li.getCurr().doc_id);
                    if (p.doc_id == f) {
                        //fi = li.getCurr().num;
                         //System.out.println("Insidde this loop"+p.pos.size());
                         fi = p.pos.size();
                        //fi = li.curr.num;// number of times t occurs in the fth document
                        //int term_frequency = 0;
                        //int document_frequency = li.IL.size();
                       // System.out.println("fi"+fi);
                        double y = ((k1 + 1) * fi) / (K + fi);
                    double x = Math.log((N - ni + 0.5) / (ni + 0.5) );
                    //System.out.println("X: "+x);
                    double z = ((k2 + 1) * qfi) / (k2 + qfi);
                    doc_score += (x*y*z);
                    flag = 1;
                          break;
                   
//                        for (int d = 0; d < document_frequency; d++) {
//
//                            //int count = 2;
//                            //count+=li.IL.get(d).num;
//                            cq += p.pos.size();
//                        }
                    }
                    
                     
                   }
                    break;
                    }
                        
                    if(flag ==1)
		  {
		  Map.Entry<Integer,Double> entry =new AbstractMap.SimpleEntry<Integer,  Double>(f,doc_score);
		  PQ.offer(entry);
		  if (PQ.size()>k)
		  {
			  PQ.poll();
		  }
		  }
                   
                    }
		   // int Psize = PQ.size();
      ArrayList<Map.Entry<Integer,Double>> data = new ArrayList<Map.Entry<Integer,Double>>();
      while(PQ.size()>0)
      {
          data.add(PQ.poll());
      }
          
      Collections.reverse(data);
      //ArrayList<String> dataTREC = new ArrayList<String>();
      //Collections.reverse(data);
      for(int ij=0;ij<data.size();ij++)
      {
    	  //Map.Entry<Integer, Double> val = PQ.poll();
      	  //data.add(val);
          rank++;
          outputWriter.write("Q" + (oj + 1) + " " + "skip" + " " + sceneid[data.get(ij).getKey()] + " " + rank + " " + data.get(ij).getValue() + " " + "kdmehta-bm25-<1.2><100>" + "\n"); 
               
          //System.out.println(val.getKey() + ":" + val.getValue()+" ");
         // k--;
      }
    }    
          
        
          outputWriter.close();
}
}

    


	
          

