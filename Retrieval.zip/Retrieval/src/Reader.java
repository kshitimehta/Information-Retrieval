/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package indexer;

//import java.io.*;
import indexer.Indexer;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader; 
import java.io.IOException;
import java.util.HashMap;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
//import org.json.simple.parser.ParseException;



/**
 *
 * @author kshitimehta
 */
        
public class Reader {
    
        static int doc_id = 0;
    public static void main(String[] args) throws FileNotFoundException, IOException, ParseException, Exception 
    {
        //String f = "/Users/kshitimehta/Desktop/FALL '19/Applied Info Retrieval 546/Assignment 1/sample.json";
        String f =  "/Users/kshitimehta/Desktop/FALL '19/Applied Info Retrieval 546/Assignment 1/shakespeare-scenes.json";
        
        //f = f.replace("\\", "/");
        File file=new File(f);
        byte[] bf = new byte[(int) file.length()];
        //String[] tokens = null;
        //int doc_id = 0;
        if(file.exists())
        {
        FileInputStream fileInputStream = new FileInputStream(file);
        fileInputStream.read(bf);  
        
         //convert file into array of bytes
 
         Object ob = new JSONParser().parse(new FileReader(f)); 
         JSONObject jo = (JSONObject) ob; 
         JSONArray load = (JSONArray) jo.get("corpus");
         Indexer io = new Indexer();
         Parameters para = new Parameters();
         
         // JSON object of parsed file. ob.get("corpus");
         // JSON Array of previous JSON object
         // for each object in JSONArray.length()
         // get all the details.
         //para.Results(load);
         io.createIL(load);
         //for (int i =0; i<load.size();i++)
         //{
         //JSONObject j = (JSONObject) load.get(i);
         //load.add(jo);
         //doc_id++;
         //System.out.println("PlayId: " + j.get("playId"));
         //String playId = (String) j.get("playId"); 
         
         //String sceneId = (String) j.get("sceneId"); 
         //System.out.println("SceneId: " + j.get("sceneId"));
         
        // Long sceneNum = (Long) j.get("sceneNum"); 
         //System.out.println("SceneNum: " + j.get("sceneNum"));
         
         //String text = (String) j.get("text"); 
         //System.out.println("Text: " + j.get("text"));
         
         //tokens = text.split("\\s+");
         //for(int k=0;k<tokens.length;k++)
               //System.out.println("Tokens: " +tokens[k]);
         //io.createIL(load);
         //}
         
         //io.main(tokens);
         //int offset = 0;
         //while (offset < f.length())
         //{
         //    int docid;
        // }
        // for (int i = 0; i < bf.length; i++)
        // {
        //    System.out.print((char) bf[i]);
         //}
        }
        /*catch (Exception e)
        {
         e.printStackTrace();
        }*/
        //System.out.println("Number of documents "+doc_id);
    }

    
    
}
