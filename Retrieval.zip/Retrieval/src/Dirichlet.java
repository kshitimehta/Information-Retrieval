/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package indexer;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.util.AbstractMap;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Map;
import java.util.PriorityQueue;

/**
 *
 * @author kshitimehta
 */
public class Dirichlet {

    public void qldm(int tot_words, double[] doc_len, int doc_length, HashMap<String, PostingsList> List, String[] sceneids) throws Exception {

        String[] sceneid = sceneids;
        int k = 10;
        double[] doc_lens = doc_len;
        double[] qfi = null;
        int cq = 0;
        double mu = 1500;
        double fi = 0.0;
        int rank;
        double max = -100000000;
        double doc_score = 0;
        int f;
        int c;
        int maxf = -1;
        BufferedWriter outputWriter = null;
        outputWriter = new BufferedWriter(new FileWriter("/Users/kshitimehta/Desktop/FALL '19/Applied Info Retrieval 546/Retrieval/TrecFiles/ql-dm.trecrun"));
        String[] user_query = {"the king queen royalty",
            "servant guard soldier",
            "hope dream sleep",
            "ghost spirit",
            "fool jester player",
            "to be or not to be",
            "alas",
            "alas poor",
            "alas poor yorick",
            "antony strumpet"};
        String[] query_terms = {};
        for (int it = 0; it < user_query.length; it++) {
            k = 10;
            rank = 0;
            //max = -1000000000;
            //maxf=-1;
            PriorityQueue<Map.Entry<Integer, Double>> PQ = new PriorityQueue<>(new Comparator<Map.Entry<Integer, Double>>() {
                @Override
                public int compare(Map.Entry<Integer, Double> v1, Map.Entry<Integer, Double> v2) {
                    if (v1.getValue() > v2.getValue()) {
                        return 1;
                    } else if (v1.getValue() < v2.getValue()) {
                        return -1;
                    }
                    return 0;
                }
            });
            ArrayList<PostingsList> al = new ArrayList<PostingsList>();
            query_terms = user_query[it].split("\\s+");

            for (String term : query_terms) {

                PostingsList p = List.get(term);
                al.add(p);

                //System.out.println("Hi "+List.get(term));
            }
//          for(int it =0;it<user_query.length;it++)
//          {
//             
//                  qfi[it] = user_query[it].length();
//              
//             
//          }
            //ArrayList<Map.Entry<Integer,Double>> entry =new ArrayList<Map.Entry<Integer, Double>>();
            for (f = 0; f < doc_length; f++) {
                doc_score = 0;
                //System.out.println("Hi here " + doc_length);
                //cq=0;

                //number of documents for term t
                for (PostingsList li : al) {
                    cq = 0;
                    for (Postings p : li.IL) {

                        fi = 0;
                        //System.out.println("This is the doc: "+pos.doc_id);
                        //System.out.println("Hi "+li.getCurr().doc_id);
                        if (p.doc_id == f) {
                            //fi = li.getCurr().num;
                            //System.out.println("Insidde this loop"+p.pos.size());
                            fi = p.pos.size();
                            //fi = li.curr.num;// number of times t occurs in the fth document
                            //int term_frequency = 0;
                            //int document_frequency = li.IL.size();
                            //System.out.println("fi"+fi);

                            cq += p.pos.size();
                            break;

//                        for (int d = 0; d < document_frequency; d++) {
//
//                            //int count = 2;
//                            //count+=li.IL.get(d).num;
//                            cq += p.pos.size();
//                        }
                        } else {
                            cq += p.pos.size();

                        }
                    }//fi=0;
                    //System.out.println("Hi "+li.getCurr().doc_id);
//                  if(li.getCurr().doc_id == (f))
//			  {
//                              //c = li.doc_pos;
//                               // System.out.println(li.getCurr().num);
//                              
//                                fi = li.curr.num;// number of times t occurs in the fth document
//                                 

                    double cal = (double) cq / (double) tot_words;
                    //cq += li.getCurr().num; //number of times term occurs in all documents in pl
//                                System.out.println("Fi "+fi);  
//                                System.out.println("CQ "+cq); 
//                                System.out.println("doc_lens[f] "+doc_lens[f]);  
                    double den = (double) (doc_lens[f] + mu);
                    double a = (double) (fi / den);
                    //System.out.println("A "+a);
                    //System.out.println("Total words"+tot_words);
                    double b = (double) mu * (double) (cal) / den;
                    //System.out.println("B "+b);
                    doc_score += (Math.log(a + b));
                    //System.out.print(doc_score);
                    //}
                    //li.skip(f);

                }
                if(doc_score != 0)
		  {
                Map.Entry<Integer, Double> entry = new AbstractMap.SimpleEntry<Integer, Double>(f, doc_score);
                PQ.offer(entry);
                if (PQ.size() > k) {
                    PQ.poll();
                }
                  }

            }

            //int Psize = PQ.size();
            ArrayList<Map.Entry<Integer, Double>> data = new ArrayList<Map.Entry<Integer, Double>>();
            while (PQ.size() > 0) {
                data.add(PQ.poll());
            }

            Collections.reverse(data);
            //ArrayList<String> dataTREC = new ArrayList<String>();
            //Collections.reverse(data);
            for (int ij = 0; ij < data.size(); ij++) {
                //Map.Entry<Integer, Double> val = PQ.poll();
                //data.add(val);
                rank++;
                outputWriter.write("Q" + (it + 1) + "\t" + "skip" + "\t" + sceneid[data.get(ij).getKey()] + "\t" + rank + "\t" + data.get(ij).getValue() + "\t" + "kdmehta-ql-dir-<1500>" + "\n");

                //System.out.println(val.getKey() + ":" + val.getValue()+" ");
                // k--;
            }//tr.loads("Q"+it,sceneid,rank,score,"jjfoley-ql-jm-<0.1>");
        }

        outputWriter.close();
    }
}
