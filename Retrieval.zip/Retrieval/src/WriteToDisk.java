/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package indexer;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.math.BigInteger;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Set;
import org.json.simple.JSONObject;
import org.json.simple.parser.ParseException;

/**
 *
 * @author kshitimehta
 */
public class WriteToDisk {
    public HashMap<String,int[]> write(HashMap List,String x,boolean compressedFlag) throws FileNotFoundException, IOException, ParseException
	{	
                RandomAccessFile w = new RandomAccessFile(x,"rw");
                Compression c = new Compression();
                ArrayList<Integer> orig = new ArrayList<Integer>();
                ArrayList<Integer> DeltaData = new ArrayList<Integer>();	
                HashMap<String,int[]> TermOffset = new HashMap<String,int[]>();
                Set<String> TermKeys = List.keySet();
		Indexer oi = new Indexer();
		long offset = 0;
                int[] LookupData = new int[4];
		
        for(String k: TermKeys)
        {	
                int [] offsetsSet = new int[4]; 
                //System.out.println(offsetsSet[0]);
        	offsetsSet[0] = (int)offset;
                
                PostingsList pl = (PostingsList) List.get(k);
    		ArrayList<Integer> WritableIL = new ArrayList<Integer>(); 
        	int term_frequency = 0;
                int document_frequency = pl.IL.size();
        	for(int d=0;d<document_frequency;d++)
        	{	
        		
        		int count = 2;
        		count+=pl.IL.get(d).num;

        		WritableIL.add(pl.IL.get(d).doc_id);
        		WritableIL.add(pl.IL.get(d).num);
        		term_frequency +=pl.IL.get(d).pos.size();
                        
        		for(int p = 0;p<pl.IL.get(d).pos.size();p++)
        		{
        			WritableIL.add(pl.IL.get(d).pos.get(p));      			
        		}
        		
        	}
        	orig = WritableIL;
                
        	if(compressedFlag == true) 
        	{
        	DeltaData = c.delta(orig);
                int dl = DeltaData.size();
        	int[] data = new int[dl];
        	for(int i = 0;i<dl;i++)
        	{
                    data[i] = DeltaData.get(i);
        	}
    		byte [] vbyteData = c.vbyteEn(data);
    		w.write(vbyteData);
        	offset = w.getFilePointer();
                //System.out.println(offsetsSet[0]+" is offset(0) for compressed data written in file");
        	offsetsSet[1] =  (int)offset - offsetsSet[0]; //the number bytes that we need to read
        	//TermOffset.put(k, offsetsSet); //Lookup information associated with term k for compressed data
        	
        	}
                
        	else
        	{
                int olength = orig.size();
            	ByteBuffer byteBuffer = ByteBuffer.allocate(olength*4);
        	for(int i = 0;i<olength;i++)
            	{
                    byteBuffer.putInt(orig.get(i));
            	}	
        	byte[] Wdata = byteBuffer.array();
        	w.write(Wdata);
                
            	offset = w.getFilePointer();
            	offsetsSet[1] = (int) offset - offsetsSet[0];
                //TermOffset.put(k, offsetsSet);	//Lookup information associated with term k for uncompressed data
        		
        	}
                
        	offsetsSet[2] = term_frequency;
        	offsetsSet[3] = document_frequency;
                TermOffset.put(k, offsetsSet);
        	
                //if(k.equals("scene"))
        	//{
        	//System.out.println("");	
        	//System.out.println(WritableIL);        		
        	//}
                
                for(int i=0;i<=3;i++)
                {
                    LookupData[i] = offsetsSet[i];
                }
                for(int i=0;i<3;i++)
                {
                    //System.out.println(LookupData[i]);
                }
                writeLookup(LookupData);
        }
        
        w.close();
        //writeLookup(LookupData);
        return TermOffset;			
	}
    
    public void writeLookup(int [] data) throws IOException
    {
        
        //BufferedReader br = new BufferedReader(new FileReader());
         BufferedWriter outputWriter = null;
        outputWriter = new BufferedWriter(new FileWriter("/Users/kshitimehta/NetBeansProjects/Indexer/Files/LookupTable.txt"));
        for (int i =0;i<data.length;i++)
        {
            //System.out.println("Writing now : "+data[i]);
            outputWriter.write(""+data[i]+"\t"); 
        }
        //System.out.println();
        
        outputWriter.close(); 
    }
}

	