/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package indexer;

import java.util.ArrayList;

/**
 *
 * @author kshitimehta
 */
public class Decompression {
    
    public ArrayList<Integer> vbyteDecode(byte [] input)
	{
		ArrayList<Integer> dorig = new ArrayList<Integer>();
		for(int i =0;i< input.length;i++)
		{
			int p = 0;
			int output = ((int) input[i] & 0x7F);
			while ((input[i] & 0x80) ==0)
			{
				i +=1;
				p += 1;
				int unsignedByte = ((int) input[i] & 0x7F);
				output |= (unsignedByte <<(7*p));
				
			}
			dorig.add(output);
		}
		return dorig;
		
	}
    
    public ArrayList<Integer> deltaDecode(ArrayList<Integer> vdata)
   {
        ArrayList<Integer> orig_data = new ArrayList<Integer>();
        int dvalue = 0;
        int count = 0;
	int i = 0;
	while(i<vdata.size())
	{
            orig_data.add(i,vdata.get(i)+count);
            count = orig_data.get(i);
            i++;
            
            orig_data.add(i,vdata.get(i));
            dvalue = vdata.get(i);
            int pos = 0;
            i++;
            while(dvalue>0)
            {   	
               orig_data.add(i, vdata.get(i)+pos);
               pos =  vdata.get(i);
               i += 1;
               dvalue -= 1;
            }
	}
    return orig_data;
   }
}
