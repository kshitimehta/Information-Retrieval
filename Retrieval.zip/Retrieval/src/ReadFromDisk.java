/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package indexer;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Arrays;

/**
 *
 * @author kshitimehta
 */
public class ReadFromDisk {
    
    public void readFromDisk(String x,int b,int offset,boolean flag) throws FileNotFoundException,IOException
	{	
		RandomAccessFile reader = new RandomAccessFile(x,"rw");
		ArrayList<Integer> inverted = new ArrayList<Integer>();
                ArrayList<Integer> finalList = new ArrayList<Integer>();
		int os = offset;
		int l = b;
		byte[] buffer = new byte[l];
		reader.seek(os);
		reader.read(buffer,0,l);	
		
		if(flag ==true)
		{
		Decompression dc = new Decompression();	
		inverted = dc.vbyteDecode(buffer);
                finalList = dc.deltaDecode(inverted);
                //System.out.println(finalList);
		}
		else
		{	
		int off = 0;
		while(off<l)
		{
                    int docId = new BigInteger((Arrays.copyOfRange(buffer, off,off+4))).intValue();
                    //System.out.println(docId);
                    inverted.add(docId);
                    off += 4;
                    int tf = new BigInteger((Arrays.copyOfRange(buffer, off,off+4))).intValue();
                    //System.out.println(tf);
                    inverted.add(tf);

                    off += 4;
                    for(int i=0;i<tf;i++)
                    {
			int pos = new BigInteger((Arrays.copyOfRange(buffer, off,off+4))).intValue();
			//System.out.println(pos);	
			inverted.add(pos);
                        
			off += 4;
                    }
                }
                finalList = inverted;
                }
                //System.out.println(finalList);
	//return finalList;
		
    }
}

   
