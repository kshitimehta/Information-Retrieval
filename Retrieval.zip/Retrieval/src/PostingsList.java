/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package indexer;

import java.util.ArrayList;
import java.util.Iterator;
import indexer.Postings;

/**
 *
 * @author kshitimehta
 */
public class PostingsList {

    ArrayList<Postings> IL = new ArrayList<Postings>();
    Iterator<Postings> It = IL.iterator();
    Postings curr = new Postings();
    int lengthIL = this.IL.size();
    int doc_pos = 0;
    int i;
    boolean aflag=false;

    PostingsList() {
    }

    ;
        //int count =0;
//        PostingsList(ArrayList<Postings> IL) 
//	{
//		  this.IL = IL;
//		  
//		  
//		  this.curr = IL.get(0);
//		  this.doc_pos = this.curr.doc_id;
//		  this.It = this.IL.iterator();
//	};
	public void addpost(int doc_id, int pos) {
        int flag = 0;
        if (this.IL.size() > 0) {
            for (i = 0; i < this.IL.size(); i++) {
                //System.out.println("hi pl for l>0");
                Postings p = this.IL.get(i);
                if (p.doc_id == doc_id) {
                    //System.out.println("hi pl for equal docids");
                    p.add(pos);
                    IL.set(i, p);
                    //curr = p;
                    flag = 1;
                    break;
                }

            }
        }
        if (flag == 0) {
           // System.out.println("the" + doc_id);
            Postings np = new Postings();
            np.doc_id = doc_id;
            np.add(pos);
            this.IL.add(np);
            if (this.aflag == false) {
                this.doc_pos = doc_id;
                this.curr = np;
                this.aflag = true;
            }
            
        }
    }

    public Postings getCurr() {
        //System.out.println(this.curr.doc_id + " "+ this.curr.num + " "+ this.curr.pos.size());
        //count+=1;
        return this.curr;
    }

    public void NextDoc() {
        if (this.It.hasNext()) {
            Postings p = It.next();
            this.curr = p;
            this.doc_pos = p.doc_id;
        }
    }

    public void skip(int d) {
        while (this.doc_pos < d) {
            this.NextDoc();
        }
    }

    public void shift(int d) {
        if (this.doc_pos == d) {
            this.NextDoc();
        }
        if (this.doc_pos < d) {
            while (this.doc_pos <= d) {
                this.NextDoc();
            }
        }
    }

}
