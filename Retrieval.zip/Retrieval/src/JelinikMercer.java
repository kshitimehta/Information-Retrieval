/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package indexer;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.util.AbstractMap;
import java.util.ArrayList;
import java.util.Map.Entry;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.PriorityQueue;

/**
 *
 * @author kshitimehta
 */
public class JelinikMercer {

    public void qljm(int tot_words, double[] doc_len, int doc_length, HashMap<String, PostingsList> List, String[] sceneids) throws Exception {

        String[] sceneid = sceneids;
        int k = 10;
        //double[] qfi = null;
        
        int cq = 0;
        double lamda = 0.1;
        double fi = 0.0;
        int rank;
        double[] doc_lens = doc_len;
        double max = -1000000000;
        double doc_score = 0;
        int f;
        int c;
        int maxf = -1;
        BufferedWriter outputWriter = null;
        outputWriter = new BufferedWriter(new FileWriter("/Users/kshitimehta/Desktop/FALL '19/Applied Info Retrieval 546/Retrieval/TrecFiles/ql-jm.trecrun"));
        String[] user_query = {"the king queen royalty",
            "servant guard soldier",
            "hope dream sleep",
            "ghost spirit",
            "fool jester player",
            "to be or not to be",
            "alas",
            "alas poor",
            "alas poor yorick",
            "antony strumpet"};
        String[] query_terms = {};
        for (int it = 0; it < user_query.length; it++) {
            rank = 0;
            k=10;
            //doc_score=0;
            HashMap<Integer, Double> store_scores = new HashMap<Integer, Double>();
            max = -1000000000;
            maxf = -1;
            PriorityQueue<Map.Entry<Integer, Double>> PQ = new PriorityQueue<>
              (new Comparator<Map.Entry<Integer, Double>>()
              {
            	  @Override
                  public int compare(Entry<Integer, Double> v1, Entry<Integer, Double> v2) {
                      if (v1.getValue() > v2.getValue()) {
                          return 1;
                      } else if (v1.getValue() < v2.getValue()) {
                          return -1;
                      }
                      return 0;
                  }
              });
            ArrayList<PostingsList> al = new ArrayList<PostingsList>();
            query_terms = user_query[it].split("\\s+");

            for (String term : query_terms) {

                PostingsList p = List.get(term);
                al.add(p);

                //System.out.println("Hi "+List.get(term));
            }
//          for(int it =0;it<user_query.length;it++)
//          {
//             
//                  qfi[it] = user_query[it].length();
//              
//             
//          }

            for (f = 0; f < doc_length; f++) {

                doc_score = 0;

                //System.out.println("Hi here " + doc_length);
                //number of documents for term t
                for (PostingsList li : al) {
                    //System.out.println("****"+ li.IL.size() +"***");
                    //if(li.IL.size() >= f)
                    //fi = 0;
                    // else  
                    cq = 0;
                    for (Postings p : li.IL) {

                        fi=0;
                        //System.out.println("This is the doc: "+pos.doc_id);
                        //System.out.println("Hi "+li.getCurr().doc_id);
                        if (p.doc_id == f) {
                            //fi = li.getCurr().num;
                            //System.out.println("Insidde this loop"+p.pos.size());
                            fi = p.pos.size();
                            //fi = li.curr.num;// number of times t occurs in the fth document
                            //int term_frequency = 0;
                            //int document_frequency = li.IL.size();
                            //System.out.println("fi"+fi);

                            cq += p.pos.size();
                            break;
//                        for (int d = 0; d < document_frequency; d++) {
//
//                            //int count = 2;
//                            //count+=li.IL.get(d).num;
//                            cq += p.pos.size();
//                        }
                        } else {
                            cq += p.pos.size();

                        }
                    }

                    double cal = (double) cq / (double) tot_words;
                    //cq += li.getCurr().num; //number of times term occurs in all documents in pl
                    //System.out.println("cq " + cq);
                    double a = (1.0 - lamda) * (double) (fi / doc_lens[f]);
                    //System.out.println("A " + a);

                    double b = (double) lamda * (double) (cal);
                    double sum = (double) (a + b);
                    //System.out.println("B " + b);
                    doc_score += (Math.log(sum));
                    //cq=0;

                    //li.skip(f);
                }
//                if (max < doc_score) {
//                    max = doc_score;
//                    maxf = f;
//                }
                   if(doc_score != 0)
		  {
		  Map.Entry<Integer,Double> entry =new AbstractMap.SimpleEntry<Integer,  Double>(f,doc_score);
		  PQ.offer(entry);
		  if (PQ.size()>k)
		  {
			  PQ.poll();
		  }
		  }
                //store_scores.put(f, doc_score);

            }
            //Map<Integer, Double> hm1 = sortByValue(store_scores);
            //LinkedHashMap<Integer, Double> reverseSortedMap = new LinkedHashMap<>();
            
//Use Comparator.reverseOrder() for reverse ordering
//            PQ.entrySet()
//                    .stream()
//                    .sorted(Map.Entry.comparingByValue(Comparator.reverseOrder()))
//                    .forEachOrdered(x -> reverseSortedMap.put(x.getKey(), x.getValue()));
//            PQ.offer(new AbstractMap.SimpleEntry(maxf, max));
//            System.out.println(max);
            
//            for (Map.Entry<Integer, Double> entry : hm1.entrySet()) {
//                PQ.offer(entry);
//                
//            }
//            Iterator itr = PQ.iterator(); 
        int Psize = PQ.size();
      ArrayList<Map.Entry<Integer,Double>> data = new ArrayList<Map.Entry<Integer,Double>>();
      while(PQ.size()>0)
      {
          data.add(PQ.poll());
      }
          
      Collections.reverse(data);
      ArrayList<String> dataTREC = new ArrayList<String>();
      //Collections.reverse(data);
      for(int ij=0;ij<data.size();ij++)
      {
    	  //Map.Entry<Integer, Double> val = PQ.poll();
      	  //data.add(val);
          rank++;
          outputWriter.write("Q" + (it + 1) + "\t" + "skip" + "\t" + sceneid[data.get(ij).getKey()] + "\t" + rank + "\t" + data.get(ij).getValue() + "\t" + "kdmehta-ql-jm-<0.1>" + "\n"); 
               
          //System.out.println(val.getKey() + ":" + val.getValue()+" ");
         // k--;
      }
//            while (itr.hasNext()) 
//            {
//                itr.next();
//            }
//            while (PQ.size() > k) {
//                Map.Entry<Integer, Double> val = PQ.poll();    
//                rank++;
//               outputWriter.write("Q" + (it + 1) + "\t" + "skip" + "\t" + sceneid[val.getKey()] + "\t" + rank + "\t" + val.getValue() + "\t" + "MKshiti-ql-jm-<0.1>" + "\n"); 
//               
//                    }
            //Iterator itr2 = PQ.iterator(); 
            
            
            
               
//            if (PQ.size() > k) {
//                PQ.poll();
//                rank++;
//
//                outputWriter.write("Q" + (it + 1) + "\t" + "skip" + "\t" + sceneid[maxf] + "\t" + rank + "\t" + max + "\t" + "MKshiti-ql-jm-<0.1>" + "\n");
//                //tr.loads("Q"+it,sceneid,rank,score,"jjfoley-ql-jm-<0.1>");
//            }
        }
        outputWriter.close();
    }

//    public static HashMap<Integer, Double> sortByValue(HashMap<Integer, Double> hm) {
//        // Create a list from elements of HashMap 
//        List<Map.Entry<Integer, Double>> list
//                = new LinkedList<Map.Entry<Integer, Double>>(hm.entrySet());
//
//        // Sort the list 
//        Collections.sort(list, new Comparator<Map.Entry<Integer, Double>>() {
//            public int compare(Map.Entry<Integer, Double> o1,
//                    Map.Entry<Integer, Double> o2) {
//                return (o1.getValue()).compareTo(o2.getValue());
//            }
//        });
//
//        // put data from sorted list to hashmap  
//        HashMap<Integer, Double> temp = new HashMap<Integer, Double>();
//        for (Map.Entry<Integer, Double> aa : list) {
//            temp.put(aa.getKey(), aa.getValue());
//        }
//        return temp;
//    }
}
