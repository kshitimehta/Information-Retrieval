/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package indexer;

import java.util.ArrayList;

/**
 *
 * @author kshitimehta
 */
public class Postings {
    int doc_id = 0;
    int num = 0;
    Postings(){}
    ArrayList<Integer> pos = new ArrayList<Integer>();
	Postings(int docid, ArrayList<Integer> position) 
	{
                //System.out.println("Hi new postings");
		this.doc_id = docid;
		if(position != null) {
                    pos = position ;
		}
		this.num = this.pos.size();
                System.out.println(num);
		
    }
	
        public void add(int pos) {
            //System.out.println("Hi new postings add method");
		this.pos.add(pos);
               // System.out.println("Hi new after");
		this.num +=1;
		
	}
        
	public void count(int docid,int pos) {
		
		this.doc_id = docid;
		this.pos.add(pos);
		this.num +=1;
		
	}
	
		
	
}
