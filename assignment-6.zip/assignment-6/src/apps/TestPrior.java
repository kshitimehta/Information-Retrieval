package apps;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import index.Index;
import index.InvertedIndex;
import retrieval.AndNode;
import retrieval.Dirichlet;
import retrieval.InferenceNetwork;
import retrieval.PriorNode;
import retrieval.ProximityNode;
import retrieval.QueryNode;
import retrieval.RetrievalModel;
import retrieval.TermNode;
/*
 * *
Q1: the king queen royalty
Q2: servant guard soldier
Q3: hope dream sleep
Q4: ghost spirit
Q5: fool jester player
Q6: to be or not to be
Q7: alas
Q8: alas poor
Q9: alas poor yorick
Q10: antony strumpet

Please run these queries using the two phrase operators, ordered window and unordered window.
For ordered, use a distance of 1 (exact phrase), for unordered, use a window width 
3*|Q| (three times the length of the query). Please run these queries with each of the 
operators: SUM, AND, OR, and MAX. Use dirichlet smoothing with μ=1500 for all runs.
 */
public class TestPrior {

	public static void main(String[] args) {
		int k = Integer.parseInt(args[0]);
		boolean compressed = Boolean.parseBoolean(args[1]);
		Index index = new InvertedIndex();
		index.load(compressed);

		RetrievalModel model = new Dirichlet(index, 1500);
		List<Map.Entry<Integer, Double>> results;
		InferenceNetwork network = new InferenceNetwork();
		QueryNode queryNode;
		ArrayList<QueryNode> children;
		
		// read in the queries
		String priorName = args[2];
		String query = "the king queen royalty";
		String outfile, runId, qId;
		int qNum = 0;
		


		// and
		outfile = priorName+".trecrun";
		runId = "kfaujdar-and-dir-1500";
		qNum = 0;
		qNum++;
			// make each of the required query nodes and run the queries
			
			children = genTermNodes(query, index, model);
			PriorNode prior=new PriorNode(index, priorName);
			children.add(prior);
			queryNode = new AndNode(children);
			results = network.runQuery(queryNode, k);
			qId = "Q" + qNum;
			boolean append = qNum > 1;
			try {
				PrintWriter writer = new PrintWriter(new FileWriter(outfile, append));
				printResults(results, index, writer, runId, qId);
				writer.close();

			} catch (IOException ex) {
				ex.printStackTrace();
			}
	}

	private static void printResults(List<Entry<Integer, Double>> results, 
			Index index, PrintWriter writer, String runId, String qId) {
		int rank = 1;
		for (Map.Entry<Integer, Double> entry : results) {
			String sceneId = index.getDocName(entry.getKey());
			String resultLine = qId + " skip " + sceneId + " " + rank + " " 
					+ entry.getValue() + " " + runId;

			writer.println(resultLine);
			rank++;
		}
	}
	private static ArrayList<QueryNode> genTermNodes(String query, Index index, RetrievalModel model) {
		String [] terms = query.split("\\s+");
		ArrayList<QueryNode> children = new ArrayList<QueryNode>();
		for (String term : terms) {
			ProximityNode node = new TermNode(term, index, model);
			children.add(node);
		}
		return children;
	}
}
