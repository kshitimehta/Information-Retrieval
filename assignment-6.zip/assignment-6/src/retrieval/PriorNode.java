package retrieval;

import index.Index;

public class PriorNode implements QueryNode {
    Index index;
    String name;

    public PriorNode(Index index, String priorname) {
        this.index = index;
        this.name = priorname;
    }

    @Override
    public Integer nextCandidate() {
        return null;
    }

    @Override
    public Double score(Integer docId) {
        return index.getPrior(name, docId);
    }

    @Override
    public int skipTo(int docId) {
	return -1;
    }

	@Override
	public boolean hasMore() {
		// TODO Auto-generated method stub
		return false;
	}
}