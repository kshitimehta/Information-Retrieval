package utilities;

public enum Compressors {
EMPTY, VBYTE;
}