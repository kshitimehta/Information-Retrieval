DEPENDENCIES TO RUN THE CODE:
JAR file: json-simple-1.1.1.jar
It can be downloaded from http://www.java2s.com/Code/Jar/j/Downloadjsonsimple111jar.htm

INSTRUCTIONS TO BUILD THE CODE:
Project was written in Eclipse
Steps to export project in eclipse:
 1. Launch IDE
 2. Click on "File" then "Import Project".


INSTRUCTIONS TO RUN THE CODE:
1. class MakePrior.java has main function which generates and stores priors.
2. class TestPrior.java has a main function which calculates scores and generated output trec run files. 